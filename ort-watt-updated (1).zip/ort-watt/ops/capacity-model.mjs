/* Capacity + cost model, built from published 2026 rates and the
   measured weight of the real ORT WATT pages.
   Every constant below is sourced, not invented. */

// ---- Measured from the built site (gzipped where applicable) ----
const KB_DESKTOP_FIRST = 384.3, KB_MOBILE_FIRST = 259.3, KB_REPEAT = 7.5;
const MOBILE_SHARE = 0.75;

// ---- Behaviour assumptions (stated so they can be challenged) ----
const PAGES_PER_SESSION   = 3.2;   // e-commerce browsing
const SESSION_SECONDS     = 180;   // 3 minutes
const PEAK_HOUR_SHARE     = 0.12;  // busiest hour = 12% of the day
const CAMPAIGN_SPIKE      = 3.0;   // an ad campaign trebles the peak hour

// DB queries per session: catalogue, search, a few product pages,
// plus cart/checkout for the minority who buy.
const DB_QUERIES_PER_SESSION = 12;
const CONVERSION = 0.02;             // 2% reach checkout
const DB_QUERIES_CHECKOUT = 25;

// ---- Netlify credit rates (published) ----
const CR_PER_GB_BANDWIDTH = 20;
const CR_PER_DEPLOY       = 15;
const DEPLOYS_PER_MONTH   = 8;
const PLANS = { Free:{credits:300,usd:0}, Personal:{credits:1000,usd:9},
                Pro:{credits:3000,usd:20} };

// ---- Neon rates (published) ----
const USD_PER_CU_HOUR = 0.106;
const USD_PER_GB_STORAGE = 0.35;
const NEON_EGRESS_FREE_GB = 100, USD_PER_GB_EGRESS = 0.10;
// max_connections by compute size (Neon published table)
const MAXCONN = {0.25:104, 0.5:225, 1:450, 2:901, 4:1802, 8:3604, 16:7208};
const POOL_FACTOR = 0.9;            // PgBouncer pool = 90% of max_connections
const POOLER_CLIENT_LIMIT = 10000;  // PgBouncer max client connections

const avgFirstKB = KB_DESKTOP_FIRST*(1-MOBILE_SHARE) + KB_MOBILE_FIRST*MOBILE_SHARE;
const sessionKB  = avgFirstKB + (PAGES_PER_SESSION-1)*KB_REPEAT + 25; // +JSON/API

function model(visitorsPerDay){
  const sessionsMo = visitorsPerDay*30;

  // --- concurrency (Little's Law) ---
  const peakSessionsPerHour = visitorsPerDay*PEAK_HOUR_SHARE;
  const concurrent = peakSessionsPerHour*SESSION_SECONDS/3600;
  const concurrentSpike = concurrent*CAMPAIGN_SPIKE;

  // --- database ---
  // Only a fraction of concurrent users are mid-query at any instant.
  // A typical query takes ~15ms within a 180s session of 12 queries.
  const queryMs = 15;
  const activeQueryRatio = (DB_QUERIES_PER_SESSION*queryMs/1000)/SESSION_SECONDS;
  const concurrentQueries = concurrentSpike*activeQueryRatio;

  // --- bandwidth ---
  const gb = sessionsMo*sessionKB/1024/1024;
  const bwCredits = gb*CR_PER_GB_BANDWIDTH;
  const credits = bwCredits + DEPLOYS_PER_MONTH*CR_PER_DEPLOY;
  const creditsWithCompute = credits*1.4;   // functions + web requests

  let plan='Enterprise', usd=null;
  for(const [name,p] of Object.entries(PLANS))
    if(creditsWithCompute<=p.credits){ plan=name; usd=p.usd; break; }

  // --- Neon compute sizing: pick smallest CU whose pool covers demand ---
  let cu = 0.25;
  for(const size of Object.keys(MAXCONN).map(Number).sort((a,b)=>a-b)){
    if(MAXCONN[size]*POOL_FACTOR >= concurrentQueries*3){ cu=size; break; } // 3x headroom
  }
  // active hours: DB scales to zero when idle; assume busy 14h/day
  const cuHours = cu*14*30;
  const neonCompute = cuHours*USD_PER_CU_HOUR;
  const neonStorage = 5*USD_PER_GB_STORAGE;          // ~5 GB incl. history
  const neonEgressGB = sessionsMo*DB_QUERIES_PER_SESSION*3/1024/1024; // ~3KB/query
  const neonEgress = Math.max(0, neonEgressGB-NEON_EGRESS_FREE_GB)*USD_PER_GB_EGRESS;
  const neon = neonCompute+neonStorage+neonEgress;

  return { visitorsPerDay, concurrent, concurrentSpike, concurrentQueries,
           gb, credits:creditsWithCompute, plan, usd, cu,
           poolSize:Math.round(MAXCONN[cu]*POOL_FACTOR), neon,
           total: (usd??0)+neon };
}

console.log('ASSUMPTIONS');
console.log(`  avg first page ${avgFirstKB.toFixed(0)} KB | session ${sessionKB.toFixed(0)} KB`);
console.log(`  ${PAGES_PER_SESSION} pages/session, ${SESSION_SECONDS}s duration`);
console.log(`  peak hour = ${PEAK_HOUR_SHARE*100}% of day, campaign spike x${CAMPAIGN_SPIKE}\n`);

const rows = [1000,5000,10000,20000,50000].map(model);
console.log('CONCURRENCY & DATABASE');
console.log('visitors/day  peak concurrent  spike  concurrent queries   CU   pool');
for(const r of rows)
  console.log(`${String(r.visitorsPerDay).padStart(11)}  ${r.concurrent.toFixed(0).padStart(15)}  ${r.concurrentSpike.toFixed(0).padStart(5)}  ${r.concurrentQueries.toFixed(1).padStart(18)}  ${String(r.cu).padStart(4)}  ${String(r.poolSize).padStart(4)}`);

console.log('\nCOST PER MONTH (USD)');
console.log('visitors/day       GB   credits      plan   Netlify    Neon   TOTAL');
for(const r of rows)
  console.log(`${String(r.visitorsPerDay).padStart(11)}  ${r.gb.toFixed(0).padStart(7)}  ${r.credits.toFixed(0).padStart(8)}  ${r.plan.padStart(8)}  ${('$'+(r.usd??'?')).padStart(8)}  ${('$'+r.neon.toFixed(0)).padStart(6)}  ${('$'+r.total.toFixed(0)).padStart(6)}`);

console.log(`\nPooler accepts up to ${POOLER_CLIENT_LIMIT.toLocaleString()} client connections regardless of CU size.`);

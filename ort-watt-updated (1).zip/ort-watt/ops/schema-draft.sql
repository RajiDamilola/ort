-- =========================================================
-- ORT WATT — product catalogue schema (DRAFT FOR REVIEW)
--
-- Design decision: specifications are FREE-FORM (Option A).
-- You type any label and any value on any product. Nothing is
-- fixed in advance.
--
-- The known weakness of free-form is drift: "Warranty" on one
-- product and "Warranty period" on the next, which makes the
-- comparison page ragged. This is handled at the interface
-- rather than in the database — see spec_label_suggestions at
-- the bottom. You are never blocked, only nudged.
-- =========================================================


-- ---------------------------------------------------------
-- CATEGORIES
-- ---------------------------------------------------------
CREATE TABLE categories (
  id            SERIAL PRIMARY KEY,
  slug          TEXT UNIQUE NOT NULL,        -- 'inverters'
  sort_order    INT  NOT NULL DEFAULT 0,     -- your chosen display order
  is_published  BOOLEAN NOT NULL DEFAULT TRUE,

  name_en       TEXT NOT NULL,
  name_fr       TEXT,
  name_ar       TEXT,

  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- ---------------------------------------------------------
-- THE ORT LABEL SYSTEM
--
-- Your four tiers are brand, not configuration, so they live in a
-- table you control rather than being frozen into the code. You can
-- rename a tier, change its colour, rewrite what customers read,
-- reorder them, or add a fifth — all from the admin area.
--
-- The colour is stored here and applied as a CSS variable, so the
-- badge, the tile mark, the comparison page and the legend all
-- follow automatically. There is no second place to update.
-- ---------------------------------------------------------
CREATE TABLE product_labels (
  id            SERIAL PRIMARY KEY,
  slug          TEXT UNIQUE NOT NULL,        -- 'approved' — stable, used in CSS
  rank          INT  NOT NULL,               -- 1 = entry tier, 4 = highest
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,

  -- Appearance
  colour        TEXT NOT NULL,               -- '#E01E14'
  text_colour   TEXT NOT NULL DEFAULT '#FFFFFF',

  -- What the customer reads
  name_en       TEXT NOT NULL,               -- 'ORT Approved'
  name_fr       TEXT,
  name_ar       TEXT,
  what_en       TEXT,                        -- the explanation on the legend
  what_fr       TEXT,
  what_ar       TEXT,

  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Your current four, seeded so nothing changes on day one.
INSERT INTO product_labels (slug, rank, colour, name_en, name_fr, name_ar) VALUES
  ('selected', 1, '#5C6472', 'ORT Selected', 'ORT S\u00e9lectionn\u00e9', 'ORT \u0645\u062e\u062a\u0627\u0631'),
  ('verified', 2, '#0B7F3D', 'ORT Verified', 'ORT V\u00e9rifi\u00e9', 'ORT \u0645\u062a\u062d\u0642\u0642'),
  ('approved', 3, '#E01E14', 'ORT Approved', 'ORT Approuv\u00e9', 'ORT \u0645\u0639\u062a\u0645\u062f'),
  ('premium',  4, '#0E2978', 'ORT Premium',  'ORT Premium',        'ORT \u0628\u0631\u064a\u0645\u064a\u0648\u0645');


-- ---------------------------------------------------------
-- PRODUCTS — the facts that are the same in every language
-- ---------------------------------------------------------
CREATE TABLE products (
  id              SERIAL PRIMARY KEY,
  slug            TEXT UNIQUE NOT NULL,      -- 'deye-sun-6k-sg04lp3'
  category_id     INT REFERENCES categories(id) ON DELETE RESTRICT,

  brand           TEXT NOT NULL,             -- 'Deye'
  model           TEXT NOT NULL,             -- 'SUN-6K-SG04LP3'
  capacity        TEXT,                      -- '6 kW'  (free text: kW, kWh, A)

  -- Pricing. The fee is stored as a percentage and the final price
  -- is DERIVED, never stored, so the two can never disagree.
  reference_price NUMERIC(12,2) NOT NULL,
  fee_percent     NUMERIC(5,2)  NOT NULL DEFAULT 10.00,
  currency        TEXT NOT NULL DEFAULT 'USD',
  price_verified_on DATE,                    -- shown to the customer

  -- ORT's own assessment. Points at the label table below, so the
  -- tiers themselves can be renamed, recoloured, reordered or added
  -- to without a developer or a database change.
  label_id        INT REFERENCES product_labels(id) ON DELETE RESTRICT,
  quality_score   NUMERIC(3,2)               -- 4.70; derived from the 5 criteria
                  CHECK (quality_score BETWEEN 0 AND 5),

  purchase_mode   TEXT NOT NULL DEFAULT 'buy'
                  CHECK (purchase_mode IN ('buy','quote')),
  availability    TEXT NOT NULL DEFAULT 'inStock'
                  CHECK (availability IN ('inStock','onRequest','outOfStock')),
  stock_qty       INT,                       -- NULL = not tracked

  figure          TEXT,                      -- line drawing, until real photos
  is_published    BOOLEAN NOT NULL DEFAULT FALSE,  -- drafts are invisible
  sort_order      INT NOT NULL DEFAULT 0,

  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ON products (category_id);
CREATE INDEX ON products (is_published);
-- Fast search across brand and model
CREATE INDEX products_search ON products
  USING GIN (to_tsvector('simple', brand || ' ' || model));


-- ---------------------------------------------------------
-- PRODUCT TEXT — one row per language
--
-- Separate table rather than name_en/name_fr/name_ar columns,
-- because adding a fourth language later then costs nothing.
-- ---------------------------------------------------------
CREATE TABLE product_text (
  product_id  INT REFERENCES products(id) ON DELETE CASCADE,
  lang        TEXT NOT NULL CHECK (lang IN ('en','fr','ar')),

  name        TEXT,        -- 'Deye SUN-6K-SG04LP3 Hybrid Inverter'
  what_is     TEXT,        -- "What is it" paragraph
  who_for     TEXT,        -- "Who it's for" paragraph
  cat_label   TEXT,        -- 'Hybrid Inverter' as shown on the card

  PRIMARY KEY (product_id, lang)
);


-- ---------------------------------------------------------
-- SPECIFICATIONS — free-form, Option A
--
-- Any label, any value, any number of rows, ordered by you.
-- Values are per-language because units are translated
-- ('5 years' / '5 ans' / 'سنوات'), but only English is required.
-- The others fall back to English when blank, so you can enter a
-- product quickly and translate later.
-- ---------------------------------------------------------
CREATE TABLE product_specs (
  id          SERIAL PRIMARY KEY,
  product_id  INT REFERENCES products(id) ON DELETE CASCADE,
  sort_order  INT NOT NULL DEFAULT 0,

  label_en    TEXT NOT NULL,      -- 'Rated power'
  label_fr    TEXT,
  label_ar    TEXT,

  value_en    TEXT NOT NULL,      -- '6 000 W'
  value_fr    TEXT,
  value_ar    TEXT
);

CREATE INDEX ON product_specs (product_id, sort_order);
-- Used to power the label suggestions described at the bottom
CREATE INDEX ON product_specs (label_en);


-- ---------------------------------------------------------
-- BULLET POINTS — three lists, one table
--
-- 'why'       -> Why we selected it
-- 'good_for'  -> Good for
-- 'not_ideal' -> Not ideal for
--
-- One table rather than three, because they behave identically.
-- Adding a fourth list later is a new value, not a new table.
-- ---------------------------------------------------------
CREATE TABLE product_points (
  id          SERIAL PRIMARY KEY,
  product_id  INT REFERENCES products(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL CHECK (kind IN ('why','good_for','not_ideal')),
  sort_order  INT NOT NULL DEFAULT 0,

  text_en     TEXT NOT NULL,
  text_fr     TEXT,
  text_ar     TEXT
);

CREATE INDEX ON product_points (product_id, kind, sort_order);


-- ---------------------------------------------------------
-- QUALITY SCORES — the five criteria
--
-- Stored separately so the headline score can be recalculated
-- and so you can see how a product was judged, not just its total.
-- ---------------------------------------------------------
CREATE TABLE product_scores (
  product_id   INT PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE,
  reliability  NUMERIC(3,2) CHECK (reliability  BETWEEN 0 AND 5),
  value        NUMERIC(3,2) CHECK (value        BETWEEN 0 AND 5),
  performance  NUMERIC(3,2) CHECK (performance  BETWEEN 0 AND 5),
  warranty     NUMERIC(3,2) CHECK (warranty     BETWEEN 0 AND 5),
  parts        NUMERIC(3,2) CHECK (parts        BETWEEN 0 AND 5),
  assessed_by  TEXT,                                  -- which engineer
  assessed_on  DATE
);


-- ---------------------------------------------------------
-- IMAGES
--
-- Files live in object storage; only the reference is stored here.
-- Never put the image bytes in the database.
-- ---------------------------------------------------------
CREATE TABLE product_images (
  id          SERIAL PRIMARY KEY,
  product_id  INT REFERENCES products(id) ON DELETE CASCADE,
  url         TEXT NOT NULL,
  alt_en      TEXT,
  alt_fr      TEXT,
  alt_ar      TEXT,
  sort_order  INT NOT NULL DEFAULT 0,
  is_primary  BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX ON product_images (product_id, sort_order);


-- ---------------------------------------------------------
-- DOCUMENTS — datasheets, certificates, manuals
-- ---------------------------------------------------------
CREATE TABLE product_documents (
  id          SERIAL PRIMARY KEY,
  product_id  INT REFERENCES products(id) ON DELETE CASCADE,
  url         TEXT NOT NULL,
  title_en    TEXT NOT NULL,
  title_fr    TEXT,
  title_ar    TEXT,
  kind        TEXT DEFAULT 'datasheet',
  sort_order  INT NOT NULL DEFAULT 0
);


-- ---------------------------------------------------------
-- EDIT HISTORY
--
-- Who changed what, and when. Worth having from day one: the
-- moment two people can edit, "why did this price change?"
-- becomes a real question with no answer unless it was recorded.
-- ---------------------------------------------------------
CREATE TABLE product_audit (
  id          SERIAL PRIMARY KEY,
  product_id  INT,
  user_id     INT,
  action      TEXT NOT NULL,       -- 'created' | 'updated' | 'published' | 'deleted'
  changes     JSONB,               -- what actually changed
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ON product_audit (product_id, created_at DESC);


-- =========================================================
-- LABEL SUGGESTIONS
--
-- This is what stops free-form specs drifting. As you type a
-- label, the admin form queries this and offers labels already
-- used on other products in the same category, most-used first.
--
-- You can always ignore it and type something new. But the easy
-- path becomes the consistent one, which is what keeps the
-- comparison page tidy without imposing a fixed template.
-- =========================================================
CREATE VIEW spec_label_suggestions AS
SELECT
  p.category_id,
  s.label_en,
  COUNT(*) AS times_used,
  -- the most common value, useful for spotting typos
  MODE() WITHIN GROUP (ORDER BY s.value_en) AS common_value
FROM product_specs s
JOIN products p ON p.id = s.product_id
GROUP BY p.category_id, s.label_en
ORDER BY p.category_id, times_used DESC;


-- =========================================================
-- CONSISTENCY REPORT
--
-- A quiet health check for the admin area: which products in a
-- category are missing a spec label that most of their siblings
-- have. Not an error, just a prompt — "9 of your 10 inverters
-- list Efficiency; this one does not."
-- =========================================================
CREATE VIEW spec_gaps AS
WITH common AS (
  SELECT p.category_id, s.label_en, COUNT(DISTINCT p.id) AS n
  FROM product_specs s
  JOIN products p ON p.id = s.product_id
  GROUP BY p.category_id, s.label_en
), totals AS (
  SELECT category_id, COUNT(*) AS total FROM products
  WHERE is_published GROUP BY category_id
)
SELECT p.id AS product_id, p.slug, c.label_en AS missing_label,
       c.n AS siblings_with_it, t.total AS siblings_total
FROM products p
JOIN common c ON c.category_id = p.category_id
JOIN totals t ON t.category_id = p.category_id
WHERE c.n >= GREATEST(2, t.total * 0.6)          -- most siblings have it
  AND NOT EXISTS (
    SELECT 1 FROM product_specs s
    WHERE s.product_id = p.id AND s.label_en = c.label_en
  )
  AND p.is_published;


-- =========================================================
-- LABEL SAFETY
--
-- ON DELETE RESTRICT above already prevents deleting a label that
-- products still carry. This view makes that visible in the admin
-- area BEFORE you try, so the message is "12 products use this,
-- move them first" rather than a database error.
--
-- Deactivating (is_active = false) is the safe alternative: the
-- label stops being offered on new products, but existing ones
-- keep displaying correctly.
-- =========================================================
CREATE VIEW label_usage AS
SELECT l.id, l.slug, l.name_en, l.rank, l.is_active,
       COUNT(p.id) AS products_using,
       COUNT(p.id) FILTER (WHERE p.is_published) AS published_using
FROM product_labels l
LEFT JOIN products p ON p.label_id = l.id
GROUP BY l.id
ORDER BY l.rank;


-- =========================================================
-- ORDERS AND DELIVERY QUOTES
--
-- A customer submits an order request with a delivery address.
-- Staff work out the freight and send a quote. The customer
-- accepts and pays.
--
-- QUOTE VALIDITY: 14 DAYS (decided, not assumed).
-- Freight rates move. An accepted quote priced six weeks ago
-- comes out of the margin, so every quote carries its own
-- expiry rather than relying on a global setting that might be
-- changed later. The date is stamped when the quote is sent.
-- =========================================================
ALTER TABLE requests ADD COLUMN reference       TEXT UNIQUE;      -- 'REQ-4821', shown to the customer
ALTER TABLE requests ADD COLUMN goods_total     NUMERIC(12,2);    -- equipment + ORT fee
ALTER TABLE requests ADD COLUMN delivery_cost   NUMERIC(12,2);    -- what staff worked out
ALTER TABLE requests ADD COLUMN quote_total     NUMERIC(12,2);    -- goods + delivery
ALTER TABLE requests ADD COLUMN quote_notes     TEXT;             -- 'ships in 2 pallets, 12-16 days'
ALTER TABLE requests ADD COLUMN quoted_at       TIMESTAMPTZ;
ALTER TABLE requests ADD COLUMN quoted_by       INT;              -- which staff member
ALTER TABLE requests ADD COLUMN quote_expires   DATE;             -- quoted_at + 14 days
ALTER TABLE requests ADD COLUMN accepted_at     TIMESTAMPTZ;
ALTER TABLE requests ADD COLUMN paid_at         TIMESTAMPTZ;

-- Delivery address, kept in its own columns so shipping zones can
-- be applied to it later. A single free-text blob cannot be sorted
-- by country or matched to a rate table.
ALTER TABLE requests ADD COLUMN addr1           TEXT;
ALTER TABLE requests ADD COLUMN addr2           TEXT;
ALTER TABLE requests ADD COLUMN state           TEXT;
ALTER TABLE requests ADD COLUMN postcode        TEXT;
ALTER TABLE requests ADD COLUMN recipient       TEXT;
ALTER TABLE requests ADD COLUMN recipient_phone TEXT;
ALTER TABLE requests ADD COLUMN whatsapp        TEXT;
ALTER TABLE requests ADD COLUMN delivery_notes  TEXT;

-- The order lifecycle. 'expired' is a real state, not an absence:
-- a customer returning on day 20 must be told the price has lapsed
-- rather than shown a stale total or a broken page.
-- new -> in_review -> quoted -> accepted -> paid -> shipped -> closed
--                        \\-> expired -> (re-quote returns it to 'quoted')
ALTER TABLE requests DROP CONSTRAINT IF EXISTS requests_status_check;
ALTER TABLE requests ADD CONSTRAINT requests_status_check CHECK (status IN (
  'new','in_review','quoted','expired','accepted','paid','shipped','closed','answered'
));

CREATE INDEX ON requests (status);
CREATE INDEX ON requests (quote_expires) WHERE status = 'quoted';


-- A quote is expired when its date has passed. Derived, never a
-- stored flag: a stored flag needs a job to keep it true, and if
-- that job fails an expired quote silently stays live.
CREATE VIEW quotes_live AS
SELECT r.*,
       (r.quote_expires < CURRENT_DATE)                    AS is_expired,
       (r.quote_expires - CURRENT_DATE)                    AS days_left
FROM requests r
WHERE r.status IN ('quoted','expired');


-- Quotes going stale in the next three days, so staff can chase
-- rather than let a deal lapse in silence.
CREATE VIEW quotes_expiring_soon AS
SELECT reference, full_name, email, whatsapp, quote_total, quote_expires,
       (quote_expires - CURRENT_DATE) AS days_left
FROM requests
WHERE status = 'quoted'
  AND quote_expires BETWEEN CURRENT_DATE AND CURRENT_DATE + 3
ORDER BY quote_expires;

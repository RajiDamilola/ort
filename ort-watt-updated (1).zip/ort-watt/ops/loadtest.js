/* =========================================================
   loadtest.js — real load testing for ORT WATT
   ---------------------------------------------------------
   Run this AGAINST A DEPLOYED SITE. It cannot be run against a
   site that does not exist, which is why the figures in the
   report are modelled rather than measured.

   Install k6 (free, open source):
     mac      brew install k6
     windows  winget install k6
     linux    see k6.io/docs

   Then, from this folder:

     BASE=https://staging.ortwatt.com k6 run loadtest.js
     BASE=https://staging.ortwatt.com STAGE=500  k6 run loadtest.js
     BASE=https://staging.ortwatt.com STAGE=900  k6 run loadtest.js
     BASE=https://staging.ortwatt.com STAGE=2000 k6 run loadtest.js

   ALWAYS test against a staging deployment, never production:
   a load test is indistinguishable from an attack, and it will
   consume real bandwidth credits.
   ========================================================= */

import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Trend, Rate, Counter } from 'k6/metrics';

const BASE  = __ENV.BASE || 'http://localhost:4000';
const STAGE = __ENV.STAGE ? Number(__ENV.STAGE) : null;

/* Custom metrics, so we can see WHICH part is slow rather than
   just "the site is slow". This is how the bottleneck is found. */
const tPage     = new Trend('t_page_html');
const tCatalog  = new Trend('t_api_catalogue');   // database read
const tSearch   = new Trend('t_api_search');      // database read, heavier
const tProduct  = new Trend('t_api_product');     // database read
const tLogin    = new Trend('t_api_login');       // bcrypt — CPU bound
const tSubmit   = new Trend('t_api_submit');      // database write
const dbErrors  = new Counter('db_errors');
const okRate    = new Rate('checks_ok');

/* The four levels the client asked about. Each ramps up, holds
   long enough to be meaningful, then ramps down. */
const PROFILES = {
  500:  [{duration:'1m',target:500},  {duration:'3m',target:500},  {duration:'1m',target:0}],
  900:  [{duration:'1m',target:900},  {duration:'3m',target:900},  {duration:'1m',target:0}],
  1000: [{duration:'1m',target:1000}, {duration:'3m',target:1000}, {duration:'1m',target:0}],
  2000: [{duration:'2m',target:2000}, {duration:'3m',target:2000}, {duration:'1m',target:0}],
};

export const options = STAGE ? {
  stages: PROFILES[STAGE] || PROFILES[500],
  thresholds: {
    // A page should still feel fast for 95% of people under load.
    't_page_html':      ['p(95)<800'],
    't_api_catalogue':  ['p(95)<1000'],
    't_api_search':     ['p(95)<1200'],
    't_api_login':      ['p(95)<1500'],   // bcrypt is deliberately slow
    'http_req_failed':  ['rate<0.01'],    // under 1% errors
    'checks_ok':        ['rate>0.99'],
  },
} : {
  /* Default: a full sweep through every level in one run, so you
     can see exactly where the curve bends. */
  stages: [
    {duration:'1m',target:100},  {duration:'2m',target:100},
    {duration:'1m',target:500},  {duration:'2m',target:500},
    {duration:'1m',target:900},  {duration:'2m',target:900},
    {duration:'1m',target:1000}, {duration:'2m',target:1000},
    {duration:'2m',target:2000}, {duration:'3m',target:2000},
    {duration:'2m',target:0},
  ],
  thresholds: { 'http_req_failed':['rate<0.05'] },
};

/* A realistic session, not a single URL hammered repeatedly.
   Hammering one cached page measures the CDN and tells you nothing
   about the database. */
export default function () {
  group('browse', () => {
    const home = http.get(`${BASE}/`, {tags:{name:'home'}});
    tPage.add(home.timings.duration);
    okRate.add(check(home, {'home 200': r => r.status === 200}));
    sleep(Math.random()*3 + 1);

    const cat = http.get(`${BASE}/api/products`, {tags:{name:'catalogue'}});
    tCatalog.add(cat.timings.duration);
    if (cat.status >= 500) dbErrors.add(1);
    okRate.add(check(cat, {'catalogue 200': r => r.status === 200}));
    sleep(Math.random()*2 + 1);
  });

  /* 60% of sessions search — this is the query that will hurt first,
     because it cannot be served from cache. */
  if (Math.random() < 0.6) {
    const terms = ['inverter','battery','panel','6kw','deye','lithium'];
    const q = terms[Math.floor(Math.random()*terms.length)];
    const s = http.get(`${BASE}/api/products?search=${q}`, {tags:{name:'search'}});
    tSearch.add(s.timings.duration);
    if (s.status >= 500) dbErrors.add(1);
    okRate.add(check(s, {'search ok': r => r.status < 400}));
    sleep(Math.random()*2 + 1);
  }

  /* 70% open a product page */
  if (Math.random() < 0.7) {
    const p = http.get(`${BASE}/api/products/deye-sun-6k-sg04lp3`, {tags:{name:'product'}});
    tProduct.add(p.timings.duration);
    okRate.add(check(p, {'product ok': r => r.status < 400}));
    sleep(Math.random()*3 + 1);
  }

  /* 5% log in. bcrypt is CPU-bound BY DESIGN — this is the request
     most likely to expose a function concurrency limit. */
  if (Math.random() < 0.05) {
    const r = http.post(`${BASE}/api/auth/login`,
      JSON.stringify({email:'loadtest@example.com', password:'wrong-on-purpose'}),
      {headers:{'Content-Type':'application/json'}, tags:{name:'login'}});
    tLogin.add(r.timings.duration);
    // 401 is the correct answer here; we are measuring time, not access
    okRate.add(check(r, {'login responded': x => x.status === 401 || x.status === 200}));
  }

  /* 2% submit an enquiry — a database WRITE, the operation that
     actually consumes a pooled connection for a meaningful period. */
  if (Math.random() < 0.02) {
    const fd = {
      kind:'ask_engineer', full_name:'Load Test', email:'loadtest@example.com',
      country:'UAE', city:'Dubai',
      message:'Automated load test submission, please ignore.',
    };
    const r = http.post(`${BASE}/api/requests`, fd, {tags:{name:'submit'}});
    tSubmit.add(r.timings.duration);
    if (r.status >= 500) dbErrors.add(1);
    okRate.add(check(r, {'submit accepted': x => x.status < 500}));
  }

  sleep(Math.random()*4 + 2);
}

export function handleSummary(data) {
  const g = k => data.metrics[k]?.values || {};
  const line = (label, m) => {
    const v = g(m);
    return v['p(95)'] === undefined ? null
      : `  ${label.padEnd(22)} avg ${String(Math.round(v.avg)).padStart(5)}ms   p95 ${String(Math.round(v['p(95)'])).padStart(5)}ms   max ${String(Math.round(v.max)).padStart(6)}ms`;
  };
  const rows = [
    line('Page (HTML/CDN)','t_page_html'),
    line('Catalogue (DB read)','t_api_catalogue'),
    line('Search (DB read)','t_api_search'),
    line('Product (DB read)','t_api_product'),
    line('Login (CPU/bcrypt)','t_api_login'),
    line('Submit (DB write)','t_api_submit'),
  ].filter(Boolean);

  const failed = (g('http_req_failed').rate || 0) * 100;
  const reqs   = g('http_reqs').count || 0;
  const vus    = data.metrics.vus_max?.values?.max || 0;

  const out = [
    '', '='.repeat(64),
    `ORT WATT load test — peak ${vus} virtual users`,
    '='.repeat(64), '',
    `  requests        ${reqs}`,
    `  failed          ${failed.toFixed(2)}%`,
    `  db 5xx errors   ${g('db_errors').count || 0}`, '',
    'WHERE THE TIME WENT', ...rows, '',
    'HOW TO READ THIS',
    '  Page slow, APIs fast .......... CDN or image weight',
    '  APIs slow, page fast .......... database or function limit',
    '  Login much slower than reads .. CPU bound, expected; watch it',
    '  db_errors above zero .......... connection pool exhausted',
    '  Errors climb only at the top .. you have found the real ceiling',
    '', '='.repeat(64), '',
  ].join('\n');

  return { stdout: out };
}

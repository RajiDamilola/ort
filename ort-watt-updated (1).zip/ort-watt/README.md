# ORT WATT

A curated solar equipment platform: ORT WATT researches, evaluates
and selects solar equipment, then backs every product with transparent
pricing and engineering support.

```
ort-watt/
├── start.command   ← Mac: double-click to launch
├── start.bat       ← Windows: double-click to launch
├── frontend/       ← the website — 21 pages
│   ├── index.html, equipment.html, product.html, compare.html …
│   ├── build-pages.js   ← regenerates the content pages
│   ├── css/  system.css (design tokens) · components.css (patterns)
│   └── js/   layout.js (shared header/footer) · i18n.js · data.js · api.js · ui.js
└── server/         ← one program: website server + API + database
```

The database is a single file (`server/data/ort.db`) that the server
creates by itself. There is **nothing separate to install for the
database** — no PostgreSQL, no passwords, no setup commands.

---

## Launching it (the easy way)

1. **Install Node.js** (version 18 or newer) once, from https://nodejs.org
2. **Double-click** `start.command` (Mac) or `start.bat` (Windows).
   - The very first time, it installs what it needs (takes a minute).
   - After that, it starts instantly.
3. It prints:  `Open your browser at:  http://localhost:4000`
4. Open that address. Pick a language. You're in.

To stop it, close the terminal window it opened (or press `Ctrl + C`).

### Launching from a terminal instead

If you prefer typing commands:

```bash
cd ort-watt/server
npm install     # first time only
npm start
```

Then open http://localhost:4000

---

## What happens on first run

The server sets everything up automatically:

- Creates the database file `server/data/ort.db`
- Creates all the tables
- Adds the equipment categories (**no products** — intentional, per the
  roadmap: the catalogue stays empty until real products are evaluated)
- Creates your first staff login:
  - email: `admin@ortwatt.com`
  - password: `ChangeMe123`

Change those before going live (see "Settings" below).

---

## Just want to preview the design?

Open `frontend/index.html` directly in your browser. You'll see the full
site and language switching. Only the parts that save data (login, forms)
need the server running.

---

## Settings (optional)

You don't need any settings to run locally. To change something (like the
admin login or the token secret) before going online:

1. Go into the `server` folder.
2. Copy `.env.example` to a new file named `.env`.
3. Edit the values, save, and restart.

---

## What exists so far

**The website (frontend)**
- Language gate — English / العربية / Français — with full right-to-left
  layout for Arabic, remembered between visits.
- Homepage built around the four principles: Selected by Engineers,
  Quality Controlled, Transparent Pricing, Technical Support.
- Equipment page in its **empty state**, as the roadmap requires.

**The server + database (backend)**
- `users` — accounts, with roles (customer / staff / admin).
- `categories` — equipment groups (added automatically, editable later).
- `products` + `product_scores` — the catalogue (empty; staff fill it in
  Stage 3), with transparent-pricing fields and the ORT evaluation
  (quality score, label, "why selected").
- `requests` + `request_files` — quote, solar study, and "Ask an
  Engineer" submissions, with file attachments.
- `suppliers` — internal-only supplier notes (never shown to customers).
- Login and registration with securely hashed passwords.
- Staff-only actions protected by role checks on the server.

### The API at a glance

| Address | Who | What it does |
|---|---|---|
| `POST /api/auth/register` | anyone | create a customer account |
| `POST /api/auth/login` | anyone | log in, get a token |
| `GET /api/auth/me` | logged in | your account details |
| `GET /api/categories` | anyone | list equipment categories |
| `GET /api/products` | anyone | list published products |
| `GET /api/products/:slug` | anyone | one product's detail |
| `POST /api/products` | staff/admin | add a product |
| `PUT /api/products/:id` | staff/admin | edit a product |
| `DELETE /api/products/:id` | staff/admin | remove a product |
| `POST /api/requests` | anyone | submit a quote / study / question |
| `GET /api/requests/mine` | logged in | your own requests |
| `GET /api/requests` | staff/admin | all requests |
| `PUT /api/requests/:id/status` | staff/admin | update a request's status |

---

## What comes next (from the roadmap)

- **Stage 1 (finishing):** the explanation pages — How We Select, Quality
  Control, ORT Approved, and the Transparent Pricing page.
- **Stage 2:** Ask-an-Engineer and Solar-Study forms wired to the server,
  product comparison, and individual product pages.
- **Stage 3:** the staff admin area (add/edit/remove products in the
  browser), the internal supplier area, and the request-status screen.
- **Stage 4:** invoicing, staff permission levels, support tickets,
  online payments.

---

## Moving from the easy database to a bigger one later

SQLite is perfect for building and for a launch. If the business grows to
very high traffic, the same code can be moved to PostgreSQL later without
changing how the site works — the database is the only piece that changes,
and it's isolated in `server/src/db.js`.

## A note on security

- Passwords are never stored as plain text; they are hashed with bcrypt.
- The `.env` file (if you create one) holds secrets — never share it.
- Supplier information is internal and has no public API route.
- Staff actions are checked on the server, not just hidden in the page.

---

---

---

---

---

## Frontend architecture

### Hero

Photographic, following the reference layout: dark field, headline on the
inline-start, glass capability cards, warm glow from the corners.

Your solar-farm photograph is the ground, served responsively —
`hero-mobile.jpg` (4:5 portrait) on phones so the array still reads,
then 960 / 1280 / 1920 crops above that. Three layers sit over it:

1. a two-axis scrim, heaviest where the type sits and clearing toward the
   inline-end so the panels stay visible;
2. brand-yellow glow bleeding from opposite corners;
3. a slow 28s drift on the image, disabled under reduced-motion.

Contrast was measured against the actual photo pixels rather than assumed:
worst case in the headline zone is **12.26:1**.

The proof panel beside the headline shows a real assessed product — highest
score in the catalogue, with its gauge, label and verification date.

### Section fixes

**Stage sequence** — on mobile this is no longer the desktop layout shrunk. It
becomes a two-column grid: a fixed `2.1rem` gutter holding the node and the
vertical spine, and a separate text column beside it. Because the spine lives
in its own grid column it is *structurally* incapable of crossing the copy,
which is what the old absolute positioning allowed.

**System diagram** — rebuilt as five illustrated components joined by arrows,
with a detail panel beneath. Every shape is a solid fill with a 2.5px outline;
the previous version used hairlines in a near-white tone on a near-white
section and was effectively invisible.

**Price flow** — three stacked cards read top to bottom, each carrying its own
amount: supplier quote `$500` → fee `10% = $50` → final `$550`. The fee card is
rendered at 64% width. The proportion is the argument.

**After you buy** — all six stages render, each with a matched illustration
(equipment, engineering, installation, commissioning, servicing, aftercare).
These were disappearing because `renderHome()` addressed elements a previous
redesign had removed; the first null threw and silently killed everything after
it. Every mount is now looked up defensively through `el()` / `set()` / `txt()`
helpers, so one missing element can no longer take out the rest of the page.

### Mobile first

The token scale is now defined **for phones first**, with the denser desktop
values layered on at 600 / 900 / 1280px — the reverse of before.

What was wrong, measured: body copy was set at 13px in 35 rules and 11px in 36
more, which is desktop density on a hand-held screen. Quantity steppers were
25.6px, language buttons 26.4px, icon buttons 35.2px — all under the 44px both
Apple and Google recommend.

Now: nothing under 14px except uppercase labels (12px), and touch targets are
keyed to `pointer:coarse` rather than a width breakpoint, so a finger gets 44px
on a tablet too while a mouse keeps the tighter controls. Inputs are 16px,
which stops iOS zooming the page on focus.

**Sections redesigned for the phone, not stacked:**

| Section | Mobile treatment |
|---|---|
| Hero cards | Swipeable snap rail, not three stacked boxes pushing the fold down |
| Product tiles | Horizontal media row (image beside text), not tall cards |
| After you buy | Numbered list with the illustration in a gutter |
| Funnel | Label and value on one row, bar full width beneath |
| Criteria / legend | Label above value, bar spanning |
| Comparison table | Sticky first column so labels stay while columns scroll |
| Filter chips | Horizontal scroll rail bleeding to the screen edge |
| Service grid | Two up, so the section stays scannable |

Prose is capped at 38ch so lines never run edge to edge.

### Product page: add to cart

The inline row has a quantity stepper and a full-width **Add to cart**.
Below 700px a **sticky bottom bar** appears once that row scrolls out of view —
never both at once. It carries the model, price, its own stepper and the button,
and wraps to two rows below 480px rather than cramping. It clears the iOS home
indicator via `env(safe-area-inset-bottom)`.

Quotation-only products get a Request quote button there instead, since they
cannot be added to a cart.

Verified: grid minimum widths at 320 / 360 / 390 / 414px, and the sticky bar
adds its own quantity (4) while the inline button falls back to the page field (1).

### Mobile fixes round 2

**Hero cards.** Titles were uppercase monospace inside a `13ch` box. In that
face "ENGINEERING" needs 84px of a 99px box, so every title broke onto three
lines — and because grid rows stretch to match, all three cards grew to that
height. Titles are now set in the body face at 1.02rem with natural wrapping.

**Score reading.** `4.4 / out of 5 / VERY GOOD` now share one baseline. The
verdict previously used `margin-inline-start:auto` with `align-self:center`,
which pushed it to the far edge and off the line the numbers sat on.

**Criteria list — the real bug.** The CSS styled `.crit` as a single row, but
in the markup `.crit` is the *container* of five `.crit-r` buttons, and
`.crit-r` had no styles at all. So the columns never aligned and `.crit:hover`
lit the whole group, which is why pressing one criterion looked like pressing
all of them. `.crit-r` is now the grid row and carries its own hover and
active state. The JavaScript was always correct.

**Price box.** Was a flex row with `justify-content:space-between`; a wrapped
label pushed its amount out of line. Now a two-column grid, so every figure
holds the same right-hand edge.

**Warranty & documentation.** Two of the four rows had empty label cells, which
is what looked broken. They now read Handled by / Documents / Certification,
and the tables are description lists whose rows stack label-over-value below
560px. The warranty term is found by matching the translated label rather than
guessing at English keys (one of which was an empty string).

**Add to cart on every product.** Three of the six placeholders were
`mode:'quote'`, so they showed Request a quote instead. All six are now
directly purchasable. The quote-only path remains in the code for products that
genuinely need pricing per order — set `mode:'quote'` on any product.

### WhatsApp

`+229 61 63 25 89`, defined once as `ORT_WHATSAPP` in `js/data.js`.
`ortWhatsApp(product)` builds a `wa.me` link with the message pre-filled and
translated, so the customer does not have to explain which product they mean.
It appears beside Add to cart on product pages at equal weight, as an icon
button in the sticky mobile bar, and on the contact page.

### One owner per component

The hero cards stayed broken through a first fix because the component was
defined in **two files at once**:

```
css/components.css   .hero-cards { grid-auto-flow: column; grid-auto-columns: 78% }
index.html           .hero-cards { grid-template-columns: 1fr }
```

`index.html` loads second, so it won `grid-template-columns` — but
`grid-auto-flow: column` from the stylesheet survived. With one explicit
column and auto-flow set to column, cards two and three were placed into
*implicit* columns at 78% each, making the row roughly 1fr + 78% + 78% wide.
That is why the text ran on one line, the row exceeded the screen, and the
cards stretched to a common height.

Fixing the title alone could never work, because the geometry was wrong.

Every hero rule — `.hero`, `.hero-cards`, `.hcard`, `.hero-h`, `.hero-sub`,
`.hero-cta`, `.hero-foot`, `.hero-facts`, `.hero-top`, `.hero-inner`,
`.specimen` — now lives only in `index.html`, at every breakpoint. A check
across the whole codebase confirms no `grid-auto-flow: column` sits alongside
a `grid-template-columns` from another file.

Two more conflicts of the same kind were found and fixed:

- `installation.html` forced `repeat(2,1fr) !important` on `.rail` below 600px,
  overriding the global mobile stack and leaving each stage about 130px wide.
  It now goes to one column, and the `!important` is gone.
- `.hero-facts` was `display:flex` in the page and `display:grid` in the
  stylesheet; the page owns it now, as a two-up grid on phones.

### Ask an Engineer: two routes

The page now opens with two cards rather than a form, each stating its own
response time so the visitor chooses on speed against what they need to send.

| | WhatsApp | Form |
|---|---|---|
| Badge | **Fastest reply** (green) | Within one business day |
| Best for | Quick questions, "will this work for me", a photo or two | Photos, bills, drawings, full appliance lists, anything needing a written record |

A note directly above the form repeats the trade-off: *if your question involves
images or large files, please use the form below — we typically reply within one
business day.*

The form's confirmation message now states the response time as well, in all
three languages, and points to WhatsApp for anything urgent. A promise made on
the page should be repeated at the moment it starts counting.

The WhatsApp link is built at runtime by `ortWhatsApp()`, so the pre-filled
message is in whichever language the visitor selected.

**Live chat was considered and rejected for now.** A widget is roughly fifteen
minutes of work, but it is only as good as the person watching it — an
unstaffed widget advertising "typically replies in 2 hours" is worse than none,
because it promises speed and then breaks the promise. WhatsApp gives the same
immediacy with a notification on a phone the team already carries, keeps the
thread if the visitor leaves the site, and handles photographs of a meter or
roof far more naturally.

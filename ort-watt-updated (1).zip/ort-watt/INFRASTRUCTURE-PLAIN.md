# ORT WATT — Website Setup, in Plain Language

Answers to your questions, without the jargon.

---

## The short version

| Your question | Short answer |
|---|---|
| Who hosts it? | Netlify |
| What does it cost? | About **$15 for the first year** |
| How many visitors can it take? | ~600/day free, ~9,400/day on the $20 plan |
| Is it secure? | Mostly — **three things must be fixed before launch** |
| Are there backups? | Yes, automatic |
| Can it grow? | Yes, by changing a setting. No rebuilding. |
| Who fixes it if it breaks? | **Nobody yet. This needs deciding.** |

---

## 1. Where the website will live

### The recommendation: Netlify

Think of most web hosting as **renting an office**: you get a fixed
space, you pay whether you use it or not, and if too many people arrive
at once, they cannot get in.

Netlify works more like **a venue that adds rooms as guests arrive**. Ten
visitors or ten thousand, it simply serves them. You are billed for what
you actually use.

### Why it suits you

Your website has copies stored in many countries. Someone in Dubai is
served from a nearby copy rather than from a single machine on the other
side of the world, so pages open quickly.

It also removes a whole category of work. With a traditional server,
somebody must keep it updated, renew its security certificate, and
restart it when it stops. With this, that is Netlify's job, not yours.

### Where the servers are

Copies of your website sit worldwide, and each visitor gets the nearest.
Your customer information will be stored in **Europe (Frankfurt)** —
the closest sensible region to Dubai and the Gulf, and noticeably faster
for phone users than a US location.

---

## 2. How much traffic it can handle

I measured your actual website rather than guessing. A first visit
downloads about **260 KB on a phone** — roughly the size of one
photograph. Returning visits are far smaller, because the phone
remembers most of it.

| Plan | Cost | Visitors per day |
|---|---|---|
| **Free** | $0 | about **600** |
| **Personal** | $9/month | about **2,900** |
| **Pro** | $20/month | about **9,400** |

Those already include a safety margin.

**For perspective:** a regional solar company usually sees 50 to 500
visitors a day in its first year. The free plan is likely to be enough
for some time, and moving up later is a single click.

### Can it cope with a busy day?

Yes — better than a traditional server would. A normal server has a
fixed size and stops responding when full. This one simply serves more
people.

**One thing to watch.** Because you pay for what you use, an unusually
busy day produces a **larger bill** rather than a crashed website.

> **Set a spending limit on the first day.** Netlify lets you cap what
> it can ever charge you. This is the single most important setting, and
> it is switched off unless you turn it on.

---

## 3. Can it grow with the business?

Yes, and this is one of the strongest reasons to choose it.

**Five or ten times the traffic:** the website copes automatically. You
change your plan for the extra allowance. Nothing is rebuilt, nothing is
moved, and the site does not go offline.

**The realistic ceiling:** comfortable up to around **15,000 visitors a
day and a few hundred orders a day.** Past that, parts of it would be
reviewed and tuned — still not rebuilt from scratch.

You are unlikely to approach that in the first few years. If you do, it
is a very good problem.

---

## 4. Security

### What is already protected

**The padlock in the address bar** (the "https") is included free and
renews itself. Visitors' connections are private.

**Attacks that try to overwhelm the site** are absorbed by the same
worldwide network that serves your pages.

**There is no server for anyone to break into.** With traditional
hosting there is a machine with a password that people constantly try to
guess. This arrangement has no such machine.

**No add-ons to go out of date.** Many small business websites are built
on WordPress, and most break-ins happen through outdated add-ons. Yours
has none, so that risk does not exist.

**Passwords are scrambled before storage.** Even with the customer list
in hand, nobody could read a password — not even you.

**Permissions are checked by the website itself**, not merely hidden.
Someone who found the staff page would still be refused, because the
check happens where it cannot be bypassed.

### Three things that MUST be fixed before launch

I would rather write these down than let them pass quietly.

1. **The starter staff password is written in the project files.** Fine
   while the site is only on your computer. The day it goes online, that
   is a front door with a published key.

2. **A security "signature" is still set to its example value.** It is
   what proves a staff login is genuine. It must be replaced with a
   private one.

3. **Nothing stops repeated password guessing.** Software can try
   thousands of passwords a minute. It needs a limit and a lockout.

I will fix all three as part of the staff-area work. **The site should
not go online until they are done.**

### Customer information

You will hold names, emails, phone numbers, enquiries and any documents
customers upload.

**You will not hold card details, and you should keep it that way.** When
you start taking payments, use a payment company whose own page handles
the card. The numbers never reach your website, which removes a very
large compliance burden.

---

## 5. Backups

**Your information is backed up automatically**, and can be rewound to a
specific moment — not just to last night. If something is deleted by
mistake at 2pm, it can be restored to 1:55pm.

**Every version of the website is kept.** If an update looks wrong, you
click once to return to the previous version. It takes seconds.

**I will also add a separate copy that you keep yourself.** The
automatic backups protect against the hosting company having a problem.
They do not protect you if your account is ever lost or closed. An
independent copy covers that, and costs almost nothing.

**How fast is recovery?** Undoing a bad update: seconds. Restoring
information: usually under an hour.

> One warning worth taking seriously: **a backup nobody has ever tested
> is a hope, not a backup.** Restore one twice a year to be certain it
> works.

---

## 6. Reliability

**Expect the site to be available about 99.9% of the time** — under an
hour of interruption in a typical month, usually far less.

**Being straight with you:** a written, compensated guarantee of uptime
only comes with the expensive corporate plan. On normal plans you get
the same reliability, but no contract promising it. For a business of
your size that is a reasonable trade.

**If part of the network fails**, visitors are automatically sent
elsewhere. There is no single machine whose failure takes you offline —
which is the main reliability advantage over renting a traditional
server.

---

## 7. Products, customers and orders

The system storing your information is the same kind used by banks and
large retailers. It is not a limitation you will meet.

**Practical limits: effectively none.** Tens of thousands of products,
customers and orders are unremarkable. Your real limit is how many
products your engineers can properly evaluate — a business question, not
a technical one.

> One point of housekeeping: the current version uses a simpler storage
> system, chosen so you could get running with no setup. Moving to the
> professional one is part of going live, and **now is by far the
> cheapest moment** — you have six sample products and no real customers.
> The same change after a year of trading would be a stressful job.

---

## 8. Who looks after it — this needs deciding

This section is about people, and I cannot answer it for you.

**What genuinely needs attention:**

| What | How often | Who |
|---|---|---|
| The hosting platform itself | Constantly | Netlify — not your concern |
| Add-ons and plugins | — | You have none |
| Occasional software updates | Every few months | **Needs an owner** |
| Adding products, answering requests | Ongoing | Your team |
| Checking nothing is silently failing | Weekly | **Needs an owner** |
| Testing a backup really restores | Twice a year | **Needs an owner** |

**On response times, I have to be direct: I cannot promise one.** I am
not an agency and have no on-call arrangement. If ORT WATT needs a
guaranteed "someone will respond within X hours", that requires a
retained developer or agency with a written agreement.

**That gap is worth closing before the business depends on the website.**

---

## 9. Email

Two separate things, often confused.

**Your mailbox** — where `hello@ortwatt.com` receives messages. Use
Google Workspace (about $6 per person per month) or Microsoft 365. Avoid
free email thrown in by a domain seller; it is unreliable for business.

**Automatic emails from the website** — request confirmations, password
resets, order notifications. Already built and tested. Free for the
first 3,000 messages a month, which is far more than you will need
early on.

### Will they land in spam?

Not if set up properly. Email providers are suspicious of messages
claiming to be from a company, because anyone can type any name in the
"from" field.

The fix is to add a few entries to your domain settings that publicly
confirm "this service is allowed to send email for us." Once done,
messages arrive normally in the inbox.

**The one thing that guarantees spam** is sending business email from a
Gmail address pretending to be your company. We are not doing that.

---

## 10. What it costs

| Item | Cost |
|---|---|
| Domain name | **$10–15 per year** |
| Hosting, to start | **Free** |
| Hosting, as you grow | $9–20 per month |
| Automatic emails | **Free** up to 3,000/month |
| Security certificate (https) | **Included** |
| Worldwide delivery network | **Included** |
| Backups | **Included** |
| Business mailboxes (optional) | About $6 per person per month |

**First year: roughly $15**, plus mailboxes if you want them.

**Later, with real traffic: about $110 to $250 per year.**

**Nothing is hidden.** The only variable is usage — a very busy month
costs more, which is why the spending limit matters.

**When renewing the domain, check the second-year price, not the
introductory offer.** Some sellers advertise $1 and renew at $40.

---

## What has to happen before the site goes live

1. Move to the professional storage system *(cheapest now)*
2. **Fix the three security items above**
3. Build the staff area so your real products replace my samples
4. Set the spending limit
5. Confirm the domain so emails send as ORT WATT
6. Add the independent backup
7. **Decide who is responsible when something breaks**

The last one is not technical, and it is the one most often forgotten.

---

## The honest summary

This setup is **fast, secure once the three items are fixed, cheap to
start, and grows without being rebuilt.** It will comfortably carry the
business for several years.

The real risk is not the technology. It is **item 7** — nobody being
responsible for the site once it is live and customers are relying on it.

---

*Prices were checked at the time of writing. Usage-based pricing
changes, so confirm before committing.*

#!/usr/bin/env node
/* =========================================================
   peek.js — "show me what is actually saved"
   ---------------------------------------------------------
   Opens the database and prints its contents in plain English.
   READ ONLY: this script cannot change or delete anything, so
   it is always safe to run.

   Run it with:   node peek.js
   ========================================================= */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

const B='\x1b[1m', D='\x1b[2m', G='\x1b[32m', Y='\x1b[33m', R='\x1b[31m', O='\x1b[0m';

const dbPath = path.join(__dirname, 'data', 'ort.db');

if (!fs.existsSync(dbPath)) {
  console.log(`\n${Y}There is no database yet.${O}`);
  console.log(`That simply means the server has not been started.`);
  console.log(`Run ${B}npm start${O} once, then try this again.\n`);
  process.exit(0);
}

let Database;
try {
  Database = require('better-sqlite3');
} catch {
  console.log(`\n${R}Cannot open the database component.${O}`);
  console.log(`Run ${B}npm install${O} first.\n`);
  process.exit(1);
}

const db = new Database(dbPath, { readonly: true });

/* Only show tables that actually exist, so this keeps working as the
   database grows in later stages. */
const tables = db.prepare(
  `SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name`
).all().map(r => r.name);

const count = t => db.prepare(`SELECT COUNT(*) c FROM "${t}"`).get().c;

console.log(`\n${B}What is stored in your database${O}`);
console.log(`${D}${dbPath}${O}`);
console.log(`${D}${(fs.statSync(dbPath).size/1024).toFixed(0)} KB${O}\n`);

console.log(`${B}Summary${O}`);
const LABEL = {
  users:'People with an account (customers and staff)',
  categories:'Product categories',
  products:'Products in the catalogue',
  product_scores:'Quality scores attached to products',
  requests:'Customer requests (the important one)',
  request_files:'Files customers attached to requests',
  suppliers:'Internal supplier notes',
};
for (const t of tables) {
  const n = count(t);
  const flag = n > 0 ? G : D;
  console.log(`  ${flag}${String(n).padStart(4)}${O}  ${LABEL[t] || t}`);
}

/* ---------- The requests, in detail ---------- */
if (tables.includes('requests')) {
  const rows = db.prepare(
    `SELECT * FROM requests ORDER BY created_at DESC LIMIT 15`
  ).all();

  console.log(`\n${B}Most recent customer requests${O}`);
  if (!rows.length) {
    console.log(`  ${D}None yet. Submit a form on the site and run this again.${O}`);
  } else {
    const KIND = {
      quote:'Quote request', study:'Solar study',
      ask_engineer:'Engineer question', installation:'Installation request',
      order:'Order',
    };
    for (const r of rows) {
      const when = new Date(r.created_at).toLocaleString();
      console.log(`\n  ${B}${KIND[r.kind] || r.kind}${O}   ${D}${when}${O}`);
      console.log(`     from : ${r.full_name || '(no name)'}  <${r.email || 'no email'}>`);
      if (r.country || r.city) console.log(`     where: ${[r.city, r.country].filter(Boolean).join(', ')}`);
      if (r.mobile)  console.log(`     phone: ${r.mobile}`);
      console.log(`     status: ${r.status}`);
      if (r.message) {
        const msg = String(r.message).replace(/\s+/g,' ').trim();
        console.log(`     says : ${msg.slice(0,150)}${msg.length>150?'…':''}`);
      }
      if (tables.includes('request_files')) {
        const files = db.prepare(`SELECT original_name FROM request_files WHERE request_id=?`).all(r.id);
        if (files.length) console.log(`     files: ${files.map(f=>f.original_name).join(', ')}`);
      }
    }
    const total = count('requests');
    if (total > rows.length) console.log(`\n  ${D}…and ${total - rows.length} older.${O}`);
  }
}

/* ---------- Accounts ---------- */
if (tables.includes('users')) {
  const users = db.prepare(`SELECT email, role, first_name, last_name FROM users ORDER BY role, email`).all();
  console.log(`\n${B}Accounts${O}`);
  for (const u of users) {
    const who = [u.first_name, u.last_name].filter(Boolean).join(' ') || '(no name)';
    const mark = u.role === 'admin' ? `${Y}admin${O}` : u.role;
    console.log(`  ${mark.padEnd(18)} ${u.email}  ${D}${who}${O}`);
  }
}

console.log(`\n${D}This tool only reads. It cannot change or delete anything.${O}\n`);
db.close();

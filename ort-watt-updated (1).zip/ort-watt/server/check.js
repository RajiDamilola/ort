#!/usr/bin/env node
/* =========================================================
   check.js — "is everything ready?"
   ---------------------------------------------------------
   Run this BEFORE starting the server, any time something
   seems wrong. It checks each thing in turn and explains any
   problem in plain language, with the exact fix.

   Run it with:   node check.js
   ========================================================= */

import fs from 'fs';
import path from 'path';
import net from 'net';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

const GREEN = '\x1b[32m', RED = '\x1b[31m', YELLOW = '\x1b[33m',
      DIM = '\x1b[2m', BOLD = '\x1b[1m', OFF = '\x1b[0m';

let problems = 0;

function ok(msg)      { console.log(`  ${GREEN}OK${OFF}    ${msg}`); }
function bad(msg, fix){ problems++; console.log(`  ${RED}PROBLEM${OFF}  ${msg}`);
                        console.log(`        ${YELLOW}How to fix:${OFF} ${fix}\n`); }
function note(msg)    { console.log(`  ${DIM}note${OFF}  ${msg}`); }

console.log(`\n${BOLD}ORT WATT — setup check${OFF}`);
console.log(`${DIM}Checking everything the server needs before it can start.${OFF}\n`);

/* ---------- 1. Is Node installed, and new enough? ---------- */
console.log(`${BOLD}1. Node.js${OFF}`);
const major = parseInt(process.versions.node.split('.')[0], 10);
if (major >= 18) {
  ok(`Node ${process.versions.node} is installed and new enough.`);
} else {
  bad(`Node ${process.versions.node} is too old. The server needs version 18 or newer.`,
      `Download the "LTS" version from https://nodejs.org and install it, then run this check again.`);
}

/* ---------- 2. Are we in the right folder? ---------- */
console.log(`\n${BOLD}2. Location${OFF}`);
if (fs.existsSync(path.join(__dirname, 'package.json'))) {
  ok(`Running from the server folder. Good.`);
} else {
  bad(`This is not the server folder.`,
      `Open a terminal, type "cd " (with a space), drag the "server" folder onto the window, press Enter, then run "node check.js" again.`);
}

/* ---------- 3. Have the building blocks been downloaded? ---------- */
console.log(`\n${BOLD}3. Required components${OFF}`);
const nm = path.join(__dirname, 'node_modules');
if (!fs.existsSync(nm)) {
  bad(`The components the server is built from have not been downloaded yet.`,
      `Type: npm install    (it takes a minute and needs internet. You only ever do this once.)`);
} else {
  const need = ['express','better-sqlite3','bcryptjs','jsonwebtoken','multer'];
  const missing = need.filter(m => !fs.existsSync(path.join(nm, m)));
  if (missing.length) {
    bad(`Some components are missing: ${missing.join(', ')}`,
        `Type: npm install`);
  } else {
    ok(`All ${need.length} required components are present.`);
    // better-sqlite3 is compiled for your specific machine, so check it loads
    try {
      require('better-sqlite3');
      ok(`The database component loads correctly on this machine.`);
    } catch (e) {
      bad(`The database component will not load. This usually means it was built for a different computer.`,
          `Type: npm rebuild better-sqlite3    — if that fails, delete the node_modules folder and run "npm install" again.`);
    }
  }
}

/* ---------- 4. Can the website files be found? ---------- */
console.log(`\n${BOLD}4. Website files${OFF}`);
const fe = path.join(__dirname, '..', 'frontend', 'index.html');
if (fs.existsSync(fe)) {
  ok(`The website was found next to the server, where it expects to be.`);
} else {
  bad(`The website folder is missing or in the wrong place.`,
      `The "server" and "frontend" folders must sit side by side inside "ort-watt". Do not move either one.`);
}

/* ---------- 5. Is the port free? ---------- */
console.log(`\n${BOLD}5. The address the site will use${OFF}`);
const PORT = process.env.PORT || 4000;
try {
  const srv = net.createServer();
  srv.once('error', err => {
    if (err.code === 'EADDRINUSE') {
      bad(`Something is already using address ${PORT}.`,
          `Either close whatever is using it, or start the server on a different one: PORT=4100 npm start`);
    }
    finish();
  });
  srv.once('listening', () => {
    ok(`Address ${PORT} is free. The site will be at http://localhost:${PORT}`);
    srv.close(finish);
  });
  srv.listen(PORT);
} catch { finish(); }

/* ---------- 6. Database ---------- */
function finish() {
  console.log(`\n${BOLD}6. Database${OFF}`);
  const dbFile = path.join(__dirname, 'data', 'ort.db');
  if (fs.existsSync(dbFile)) {
    const kb = (fs.statSync(dbFile).size / 1024).toFixed(0);
    ok(`Database file exists (${kb} KB). Your saved data lives here.`);
    note(`Full path: ${dbFile}`);
    note(`To wipe everything and start fresh, delete that one file.`);
  } else {
    ok(`No database yet — it will create itself the first time you start the server.`);
  }

  /* ---------- Verdict ---------- */
  console.log(`\n${BOLD}${'-'.repeat(52)}${OFF}`);
  if (problems === 0) {
    console.log(`${GREEN}${BOLD}Everything is ready.${OFF}\n`);
    console.log(`Next step — start the server by typing:\n`);
    console.log(`    ${BOLD}npm start${OFF}\n`);
    console.log(`Then open a browser at ${BOLD}http://localhost:${PORT}${OFF}`);
    console.log(`${DIM}To stop the server later, click the terminal and press Ctrl+C.${OFF}\n`);
  } else {
    console.log(`${RED}${BOLD}${problems} thing${problems>1?'s':''} need${problems>1?'':'s'} fixing.${OFF}`);
    console.log(`Work through the fixes above, then run ${BOLD}node check.js${OFF} again.\n`);
  }
}

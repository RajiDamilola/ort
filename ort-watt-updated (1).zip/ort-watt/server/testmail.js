#!/usr/bin/env node
/* =========================================================
   testmail.js — "is email working?"
   ---------------------------------------------------------
   Sends one pretend customer request through the real
   notification path, so you can check your email setup
   without filling in a form on the site.

   Run it with:   node testmail.js
   ========================================================= */

import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { mailerStatus, notifyNewRequest } from './src/mailer.js';
import { config } from './src/config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const B='\x1b[1m', D='\x1b[2m', G='\x1b[32m', Y='\x1b[33m', O='\x1b[0m';

console.log(`\n${B}Email test${O}\n`);

const st = mailerStatus();

if (st.mode === 'outbox') {
  console.log(`${Y}Email is NOT being sent.${O}`);
  console.log(`Reason: ${st.why}\n`);
  console.log(`This is not a fault. The server writes each email to a file`);
  console.log(`instead, so you can see exactly what would have been sent.`);
  console.log(`Nothing is lost, and customer requests still save normally.\n`);
} else {
  console.log(`${G}Email is live.${O}`);
  console.log(`Sending through: ${st.why}`);
  console.log(`Team address   : ${config.notifyEmail}\n`);
}

const pretend = {
  id: 'req_TESTMAIL',
  kind: 'ask_engineer',
  full_name: 'Test Customer',
  email: config.notifyEmail,        // send the customer copy to yourself
  mobile: '+971 50 000 0000',
  country: 'United Arab Emirates',
  city: 'Dubai',
  lang: 'en',
  message: 'This is a test. I have 3 air conditioners, a fridge and a water pump, and I need about 8 hours of backup.',
  status: 'new',
  created_at: new Date().toISOString(),
};

console.log(`${D}Sending a pretend request...${O}\n`);
await notifyNewRequest(pretend, [{ originalname: 'example-electricity-bill.pdf' }]);

const outbox = path.join(__dirname, 'data', 'outbox');
console.log();

if (st.mode === 'outbox') {
  const files = fs.existsSync(outbox)
    ? fs.readdirSync(outbox).sort().slice(-2)
    : [];
  if (files.length) {
    console.log(`${B}Written to:${O} ${outbox}\n`);
    for (const f of files) {
      console.log(`${D}${'-'.repeat(52)}${O}`);
      console.log(fs.readFileSync(path.join(outbox, f), 'utf8').trim());
      console.log();
    }
    console.log(`${D}${'-'.repeat(52)}${O}`);
    console.log(`\nThat is exactly what your customers and your team would receive.`);
    console.log(`To send these for real, fill in the SMTP settings in ${B}.env${O}`);
    console.log(`then run this again. See STAGE-2-WALKTHROUGH.md, Part 8.\n`);
  }
} else {
  console.log(`${G}Two emails were sent to ${config.notifyEmail}${O}`);
  console.log(`  1. the team notification`);
  console.log(`  2. the customer acknowledgement\n`);
  console.log(`Check that inbox now. If nothing arrives within a few minutes,`);
  console.log(`look in the spam folder before assuming it failed.\n`);
}

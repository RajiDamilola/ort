// =========================================================
//  config.js — the few settings the server needs.
//
//  Everything has a sensible default so it runs with zero
//  setup. For real use, create a file named ".env" next to
//  package.json to override any of these (see .env.example).
// =========================================================

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// A tiny .env reader so we don't need an extra library.
// It looks for a ".env" file and loads KEY=value lines.
const envPath = path.join(__dirname, '../.env');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);
    if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

export const config = {
  /* How long a delivery quote stays valid, in days.
     Freight rates move, so a quote accepted long after it was
     priced comes out of the margin. Stamped onto each quote when
     it is sent, so changing this never alters quotes already out. */
  quoteValidDays: Number(process.env.QUOTE_VALID_DAYS || 14),

  port: process.env.PORT || 4000,

  // The login-token secret. Fine for local use as-is; change
  // it to a long random string before putting the site online.
  jwtSecret: process.env.JWT_SECRET || 'ort-watt-local-dev-secret-change-me',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',

  // The first staff login, created automatically on first run.
  adminEmail: process.env.ADMIN_EMAIL || 'admin@ortwatt.com',
  adminPassword: process.env.ADMIN_PASSWORD || 'ChangeMe123',

  // Where the database file lives.
  dbFile: path.join(__dirname, '../data/ort.db'),

  /* ---------- Email ----------
     Leave these blank and the server runs in "outbox mode": emails
     are written to data/outbox/ as readable files instead of being
     sent, so you can see exactly what customers would receive
     before setting up a real mail account. */
  /* Resend: a single API key instead of four SMTP settings.
     If this is present it is used in preference to SMTP. */
  resendKey: process.env.RESEND_API_KEY || '',

  smtp: {
    host: process.env.SMTP_HOST || '',
    port: Number(process.env.SMTP_PORT || 587),
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
  },

  // Who gets told when a customer submits something.
  notifyEmail: process.env.NOTIFY_EMAIL || process.env.SMTP_USER || 'admin@ortwatt.com',

  // The "from" line customers will see.
  mailFrom: process.env.MAIL_FROM || 'ORT WATT <no-reply@ortwatt.com>',

  // Shown in the acknowledgement email as the faster route.
  whatsapp: process.env.WHATSAPP_NUMBER || '+229 61 63 25 89',
};

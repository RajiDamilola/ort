/* =========================================================
   mailer.js — telling people a request arrived.
   ---------------------------------------------------------
   Two emails go out when a customer submits something:

     1. To ORT      "a new request arrived, here it is"
     2. To customer "we have it, here is when we will reply"

   THE IMPORTANT RULE
   Email must never break the form. If the mail service is
   down, misconfigured, or simply not set up yet, the customer
   request is still saved and the customer still sees their
   confirmation. Everything here is wrapped so that a failure
   is logged and then ignored.

   BEFORE YOU CONFIGURE ANYTHING
   With no settings, this runs in "outbox mode": every email is
   written to server/data/outbox/ as a readable file and printed
   to the terminal. Nothing is sent. That lets you see exactly
   what your customers would receive before involving a real
   mail service.
   ========================================================= */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { config } from './config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUTBOX = path.join(__dirname, '../data/outbox');

/* Nodemailer is optional. If it is not installed we stay in
   outbox mode rather than crashing the server. */
let nodemailer = null;
try {
  nodemailer = (await import('nodemailer')).default;
} catch {
  /* not installed — outbox mode */
}

const configured = Boolean(
  nodemailer && config.smtp.host && config.smtp.user && config.smtp.pass
);

let transport = null;
if (configured) {
  transport = nodemailer.createTransport({
    host: config.smtp.host,
    port: config.smtp.port,
    secure: config.smtp.port === 465,
    auth: { user: config.smtp.user, pass: config.smtp.pass },
  });
}

export function mailerStatus() {
  if (config.resendKey) return { mode: 'live', why: 'sending through Resend' };
  if (!nodemailer) return { mode: 'outbox', why: 'no RESEND_API_KEY, and nodemailer is not installed' };
  if (!config.smtp.host) return { mode: 'outbox', why: 'SMTP_HOST is not set in .env' };
  if (!config.smtp.user) return { mode: 'outbox', why: 'SMTP_USER is not set in .env' };
  if (!config.smtp.pass) return { mode: 'outbox', why: 'SMTP_PASS is not set in .env' };
  return { mode: 'live', why: `sending through ${config.smtp.host}` };
}

/* ---------- Sending ---------- */
async function deliver({ to, subject, text }) {
  if (!to) return;

  /* Resend first: one API key, no host/port/password to get wrong.
     It is a plain HTTPS call, so there is nothing extra to install. */
  if (config.resendKey) {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${config.resendKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ from: config.mailFrom, to: [to], subject, text }),
    });
    if (!res.ok) {
      const detail = await res.text().catch(() => '');
      throw new Error(`Resend refused the message (${res.status}). ${detail.slice(0,200)}`);
    }
    console.log(`  [email sent via Resend] ${subject}  ->  ${to}`);
    return;
  }

  if (!configured) {
    // Outbox mode: write it where a human can read it.
    fs.mkdirSync(OUTBOX, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const safe = String(to).replace(/[^a-z0-9@._-]/gi, '_');
    const file = path.join(OUTBOX, `${stamp}__${safe}.txt`);
    fs.writeFileSync(file,
      `To: ${to}\nFrom: ${config.mailFrom}\nSubject: ${subject}\n\n${text}\n`);
    console.log(`  [email not sent — saved to outbox] ${subject}  ->  ${to}`);
    return;
  }

  await transport.sendMail({ from: config.mailFrom, to, subject, text });
  console.log(`  [email sent] ${subject}  ->  ${to}`);
}

/* ---------- What the customer sees ----------
   Written in the language they used on the site. Kept short and
   plain: the job of this email is to stop them wondering. */
const KIND_LABEL = {
  en: { quote:'quote request', study:'solar study request',
        ask_engineer:'question for our engineers', installation:'installation request',
        order:'order request' },
  fr: { quote:'demande de devis', study:'demande d\u2019\u00e9tude solaire',
        ask_engineer:'question pour nos ing\u00e9nieurs', installation:'demande d\u2019installation',
        order:'demande de commande' },
  ar: { quote:'طلب عرض سعر', study:'طلب دراسة شمسية',
        ask_engineer:'سؤال لمهندسينا', installation:'طلب تركيب',
        order:'طلب شراء' },
};

const ACK = {
  en: (name, kind, ref) =>
`Hello ${name || 'there'},

We have received your ${kind}. Thank you.

An ORT WATT engineer will reply by email, normally within one
business day. If you need an answer sooner, message us on WhatsApp
at ${config.whatsapp} and we will usually respond the same working day.

Your reference is ${ref}. Quoting it helps us find your request quickly.

ORT WATT
Solar equipment, engineering and energy solutions
Dubai, United Arab Emirates`,

  fr: (name, kind, ref) =>
`Bonjour ${name || ''},

Nous avons bien re\u00e7u votre ${kind}. Merci.

Un ing\u00e9nieur ORT WATT vous r\u00e9pondra par e-mail, normalement
sous un jour ouvr\u00e9. Si vous souhaitez une r\u00e9ponse plus rapide,
\u00e9crivez-nous sur WhatsApp au ${config.whatsapp} et nous r\u00e9pondrons
g\u00e9n\u00e9ralement le jour ouvr\u00e9 m\u00eame.

Votre r\u00e9f\u00e9rence est ${ref}. La rappeler nous aide \u00e0 retrouver
rapidement votre demande.

ORT WATT
\u00c9quipements solaires, ing\u00e9nierie et solutions \u00e9nerg\u00e9tiques
Duba\u00ef, \u00c9mirats arabes unis`,

  ar: (name, kind, ref) =>
`مرحباً ${name || ''}،

لقد استلمنا ${kind} الخاص بك. شكراً لك.

سيرد عليك مهندس من ORT WATT عبر البريد الإلكتروني، عادةً خلال
يوم عمل واحد. وإذا كنت بحاجة إلى رد أسرع، راسلنا على واتساب
على الرقم ${config.whatsapp} وسنرد عادةً في يوم العمل نفسه.

رقمك المرجعي هو ${ref}. ذكره يساعدنا في العثور على طلبك بسرعة.

ORT WATT
معدات شمسية وهندسة وحلول للطاقة
دبي، الإمارات العربية المتحدة`,
};

const ACK_SUBJECT = {
  en: ref => `We have your request (${ref}) — ORT WATT`,
  fr: ref => `Nous avons bien re\u00e7u votre demande (${ref}) — ORT WATT`,
  ar: ref => `استلمنا طلبك (${ref}) — ORT WATT`,
};

/* ---------- Public: called after a request is saved ---------- */
export async function notifyNewRequest(request, files = []) {
  const lang = ['en','fr','ar'].includes(request.lang) ? request.lang : 'en';
  const ref  = String(request.id).slice(0, 8).toUpperCase();
  const kind = (KIND_LABEL[lang] || KIND_LABEL.en)[request.kind] || request.kind;

  /* --- 1. Alert the ORT team --- */
  const lines = [
    `A new ${request.kind} came in through the website.`,
    ``,
    `Reference : ${ref}`,
    `Type      : ${request.kind}`,
    `Name      : ${request.full_name || '(not given)'}`,
    `Email     : ${request.email || '(not given)'}`,
    `Phone     : ${request.mobile || '(not given)'}`,
    `Location  : ${[request.city, request.country].filter(Boolean).join(', ') || '(not given)'}`,
    `Language  : ${lang}`,
    ``,
    `What they wrote:`,
    `${request.message || '(nothing written)'}`,
  ];
  if (files.length) {
    lines.push(``, `Attachments (${files.length}):`);
    files.forEach(f => lines.push(`  - ${f.originalname}`));
  }
  lines.push(
    ``,
    `Reply to the customer at: ${request.email || '(no email given)'}`,
    `Received ${new Date().toLocaleString()}`
  );

  await deliver({
    to: config.notifyEmail,
    subject: `[${request.kind}] ${request.full_name || 'Website enquiry'} — ${ref}`,
    text: lines.join('\n'),
  });

  /* --- 2. Reassure the customer --- */
  if (request.email) {
    await deliver({
      to: request.email,
      subject: (ACK_SUBJECT[lang] || ACK_SUBJECT.en)(ref),
      text: (ACK[lang] || ACK.en)(request.full_name, kind, ref),
    });
  }
}

/* Never let an email problem reach the customer. Call this one. */
export function notifySafely(request, files) {
  notifyNewRequest(request, files).catch(err => {
    console.error(`  [email failed, request still saved] ${err.message}`);
  });
}

// =========================================================
//  routes/products.js — the equipment catalogue.
//
//  Public:  GET /api/categories, GET /api/products, GET /api/products/:slug
//  Staff:   POST /api/products, PUT /api/products/:id, DELETE /api/products/:id
//
//  The writing routes are locked to staff/admin — that's how
//  "staff control the catalogue" (roadmap Stage 3) is enforced.
// =========================================================

import express from 'express';
import { db, newId } from '../db.js';
import { requireRole } from '../middleware/auth.js';

const router = express.Router();

const slugify = (t) => String(t).toLowerCase().trim()
  .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

// ---- Categories (public) ----
router.get('/categories', (_req, res) => {
  const categories = db.prepare('SELECT * FROM categories ORDER BY sort_order, name_en').all();
  res.json({ categories });
});

// ---- List published products (public) ----
router.get('/products', (req, res) => {
  const { category } = req.query;
  let sql = `
    SELECT p.*, c.slug AS category_slug, c.name_en AS category_name_en
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    WHERE p.is_published = 1`;
  const params = [];
  if (category) { sql += ' AND c.slug = ?'; params.push(category); }
  sql += ' ORDER BY p.created_at DESC';
  const products = db.prepare(sql).all(...params);
  res.json({ products });
});

// ---- One product with sub-scores (public) ----
router.get('/products/:slug', (req, res) => {
  const product = db.prepare(`
    SELECT p.*, c.slug AS category_slug
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    WHERE p.slug = ? AND p.is_published = 1
  `).get(req.params.slug);
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  product.scores = db.prepare('SELECT * FROM product_scores WHERE product_id = ?').get(product.id) || null;
  res.json({ product });
});

// ---- Add a product (staff/admin) ----
router.post('/products', requireRole('staff', 'admin'), (req, res) => {
  const b = req.body;
  if (!b.brand || !b.model) {
    return res.status(400).json({ error: 'Brand and model are required.' });
  }
  const id = newId();
  const slug = b.slug || slugify(`${b.brand}-${b.model}`);
  try {
    db.prepare(`
      INSERT INTO products
        (id, category_id, brand, model, slug, name_en, name_fr, name_ar, power_capacity,
         reference_price, fee_percent, price_verified_on, quality_score, ort_label,
         why_selected_en, why_selected_fr, why_selected_ar, purchase_mode, availability, is_published)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(
      id, b.category_id || null, b.brand, b.model, slug,
      b.name_en || b.model, b.name_fr || b.model, b.name_ar || b.model,
      b.power_capacity || null,
      b.reference_price || 0, b.fee_percent ?? 10, b.price_verified_on || null,
      b.quality_score || null, b.ort_label || 'ORT SELECTED',
      b.why_selected_en || null, b.why_selected_fr || null, b.why_selected_ar || null,
      b.purchase_mode || 'quote', b.availability || 'in_stock',
      b.is_published ? 1 : 0
    );

    if (b.scores) {
      const s = b.scores;
      db.prepare(`
        INSERT INTO product_scores (product_id, reliability, value_for_money, performance, warranty, spare_parts)
        VALUES (?,?,?,?,?,?)
      `).run(id, s.reliability || null, s.value_for_money || null, s.performance || null, s.warranty || null, s.spare_parts || null);
    }

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    res.status(201).json({ product });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not save the product.' });
  }
});

// ---- Edit a product (staff/admin) ----
router.put('/products/:id', requireRole('staff', 'admin'), (req, res) => {
  const b = req.body;
  const current = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!current) return res.status(404).json({ error: 'Product not found.' });

  // Keep the old value when a field isn't provided.
  const merged = {
    category_id: b.category_id ?? current.category_id,
    brand: b.brand ?? current.brand,
    model: b.model ?? current.model,
    name_en: b.name_en ?? current.name_en,
    name_fr: b.name_fr ?? current.name_fr,
    name_ar: b.name_ar ?? current.name_ar,
    power_capacity: b.power_capacity ?? current.power_capacity,
    reference_price: b.reference_price ?? current.reference_price,
    fee_percent: b.fee_percent ?? current.fee_percent,
    price_verified_on: b.price_verified_on ?? current.price_verified_on,
    quality_score: b.quality_score ?? current.quality_score,
    ort_label: b.ort_label ?? current.ort_label,
    why_selected_en: b.why_selected_en ?? current.why_selected_en,
    why_selected_fr: b.why_selected_fr ?? current.why_selected_fr,
    why_selected_ar: b.why_selected_ar ?? current.why_selected_ar,
    purchase_mode: b.purchase_mode ?? current.purchase_mode,
    availability: b.availability ?? current.availability,
    is_published: b.is_published === undefined ? current.is_published : (b.is_published ? 1 : 0),
  };

  db.prepare(`
    UPDATE products SET
      category_id=?, brand=?, model=?, name_en=?, name_fr=?, name_ar=?, power_capacity=?,
      reference_price=?, fee_percent=?, price_verified_on=?, quality_score=?, ort_label=?,
      why_selected_en=?, why_selected_fr=?, why_selected_ar=?, purchase_mode=?, availability=?,
      is_published=?, updated_at=datetime('now')
    WHERE id=?
  `).run(
    merged.category_id, merged.brand, merged.model, merged.name_en, merged.name_fr, merged.name_ar,
    merged.power_capacity, merged.reference_price, merged.fee_percent, merged.price_verified_on,
    merged.quality_score, merged.ort_label, merged.why_selected_en, merged.why_selected_fr,
    merged.why_selected_ar, merged.purchase_mode, merged.availability, merged.is_published,
    req.params.id
  );

  res.json({ product: db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id) });
});

// ---- Delete a product (staff/admin) ----
router.delete('/products/:id', requireRole('staff', 'admin'), (req, res) => {
  const info = db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Product not found.' });
  res.json({ ok: true });
});

export default router;

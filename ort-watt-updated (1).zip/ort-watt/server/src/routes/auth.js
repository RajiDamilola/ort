// =========================================================
//  routes/auth.js — accounts: register, login, "who am I".
//    POST /api/auth/register
//    POST /api/auth/login
//    GET  /api/auth/me
// =========================================================

import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db, newId } from '../db.js';
import { config } from '../config.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

function makeToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role, email: user.email },
    config.jwtSecret,
    { expiresIn: config.jwtExpiresIn }
  );
}

// --- Register a new customer ---
router.post('/register', (req, res) => {
  const { first_name, last_name, email, password, confirm_password,
          mobile, whatsapp, company, country } = req.body;

  if (!first_name || !last_name || !email || !password) {
    return res.status(400).json({ error: 'Please fill in your name, email and password.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  }
  if (confirm_password !== undefined && password !== confirm_password) {
    return res.status(400).json({ error: 'The two passwords do not match.' });
  }

  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (exists) {
    return res.status(409).json({ error: 'An account with that email already exists.' });
  }

  const id = newId();
  const hash = bcrypt.hashSync(password, 10);
  db.prepare(`
    INSERT INTO users (id, first_name, last_name, email, password_hash,
                       mobile, whatsapp, company, country, role)
    VALUES (?, ?, ?, ?, ?, ?, 'customer')
  `).run(id, first_name, last_name, email, hash,
         mobile || null, whatsapp || null, company || null, country || null);

  /* Checkout prefills from this object, so it must carry every
     contact field the account holds. Returning a partial user is
     why the checkout form would have asked for a phone number the
     customer had already given at signup. */
  const user = { id, first_name, last_name, email, role: 'customer',
                 mobile: mobile || null, whatsapp: whatsapp || null,
                 company: company || null, country: country || null };
  res.status(201).json({ user, token: makeToken(user) });
});

// --- Log in ---
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Please enter your email and password.' });
  }

  const user = db.prepare(
    'SELECT id, first_name, last_name, email, password_hash, mobile, whatsapp, company, country, role FROM users WHERE email = ?'
  ).get(email);

  // Same message either way, so we don't reveal which emails exist.
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  }

  delete user.password_hash;
  res.json({ user, token: makeToken(user) });
});

// --- Current logged-in user ---
router.get('/me', requireAuth, (req, res) => {
  const user = db.prepare(
    'SELECT id, first_name, last_name, email, mobile, whatsapp, company, country, role, created_at FROM users WHERE id = ?'
  ).get(req.user.id);
  res.json({ user });
});

export default router;

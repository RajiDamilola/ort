// =========================================================
//  routes/requests.js — everything a customer sends in.
//  Quote, solar study, or "Ask an Engineer", with file uploads.
//
//  Public/customer: POST /api/requests, GET /api/requests/mine
//  Staff/admin:     GET /api/requests, PUT /api/requests/:id/status
// =========================================================

import express from 'express';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { db, newId } from '../db.js';
import { requireAuth, requireRole, optionalAuth } from '../middleware/auth.js';
import { notifySafely } from '../mailer.js';

const router = express.Router();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Uploaded files are saved to /uploads; only the path is stored in the DB.
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, path.join(__dirname, '../../uploads')),
  filename: (_req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  },
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } }); // 10 MB each

// --- Submit a request (guest or logged in), up to 5 files ---
router.post('/requests', upload.array('files', 5), (req, res) => {
  const b = req.body;
  // 'order' comes from the checkout page. It was missing here, so every
  // order submission was being rejected with "Unknown request type".
  const validKinds = ['quote', 'study', 'ask_engineer', 'installation', 'order'];
  if (!validKinds.includes(b.kind)) {
    return res.status(400).json({ error: 'Unknown request type.' });
  }
  if (!b.message && b.kind === 'ask_engineer') {
    return res.status(400).json({ error: 'Please describe your situation so an engineer can help.' });
  }

  const auth = optionalAuth(req); // attach user id if logged in, else guest
  const id = newId();
  db.prepare(`
    INSERT INTO requests
      (id, user_id, kind, product_id, full_name, email, mobile, country, city, message, lang)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)
  `).run(
    id, auth ? auth.id : null, b.kind, b.product_id || null,
    b.full_name || null, b.email || null, b.mobile || null,
    b.country || null, b.city || null, b.message || null,
    ['en','fr','ar'].includes(b.lang) ? b.lang : 'en'
  );

  if (req.files && req.files.length) {
    const insertFile = db.prepare(`
      INSERT INTO request_files (id, request_id, file_path, original_name)
      VALUES (?,?,?,?)
    `);
    for (const f of req.files) {
      insertFile.run(newId(), id, `/uploads/${f.filename}`, f.originalname);
    }
  }

  const saved = db.prepare('SELECT * FROM requests WHERE id = ?').get(id);

  // Answer the customer FIRST, then send email in the background.
  // Nothing about the email can delay or break their confirmation.
  res.status(201).json({ request: saved });
  notifySafely(saved, req.files || []);
});

// --- A customer's own requests ---
router.get('/requests/mine', requireAuth, (req, res) => {
  const requests = db.prepare(`
    SELECT r.*, p.brand, p.model
    FROM requests r
    LEFT JOIN products p ON p.id = r.product_id
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
  `).all(req.user.id);
  res.json({ requests });
});

// --- Staff: see every request ---
router.get('/requests', requireRole('staff', 'admin'), (req, res) => {
  const { status, kind } = req.query;
  let sql = `
    SELECT r.*, u.first_name, u.last_name, p.brand, p.model
    FROM requests r
    LEFT JOIN users u ON u.id = r.user_id
    LEFT JOIN products p ON p.id = r.product_id
    WHERE 1=1`;
  const params = [];
  if (status) { sql += ' AND r.status = ?'; params.push(status); }
  if (kind)   { sql += ' AND r.kind = ?';   params.push(kind); }
  sql += ' ORDER BY r.created_at DESC';
  res.json({ requests: db.prepare(sql).all(...params) });
});

// --- Staff: update a request's status ---
router.put('/requests/:id/status', requireRole('staff', 'admin'), (req, res) => {
  const { status } = req.body;
  const allowed = ['new', 'in_review', 'quoted', 'answered', 'closed'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: 'That status is not allowed.' });
  }
  const info = db.prepare(
    `UPDATE requests SET status = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(status, req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Request not found.' });
  res.json({ request: db.prepare('SELECT * FROM requests WHERE id = ?').get(req.params.id) });
});

export default router;

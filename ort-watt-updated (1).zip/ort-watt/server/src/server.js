// =========================================================
//  server.js — the whole thing, in one place.
//
//  Running "npm start" does everything:
//    1. Opens (and on first run, builds) the SQLite database.
//    2. Serves the website (the frontend folder).
//    3. Serves the API under /api.
//
//  Because the website and API share ONE address, there is no
//  CORS setup and no second terminal. Open the printed address
//  in your browser and you're done.
// =========================================================

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

import './db.js'; // opens + initialises the database on import
import { config } from './config.js';
import authRoutes from './routes/auth.js';
import productRoutes from './routes/products.js';
import requestRoutes from './routes/requests.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.use(express.json());

// Serve uploaded files (product photos, datasheets, customer bills).
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// The API.
app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'ORT WATT' }));
app.use('/api/auth', authRoutes);
app.use('/api', productRoutes);
app.use('/api', requestRoutes);

// Anything that isn't an API call is served from the website folder.
// (The frontend lives one level up, in ../../frontend.)
const frontendDir = path.join(__dirname, '../../frontend');
app.use(express.static(frontendDir));

// If someone opens the site root, send the homepage.
app.get('/', (_req, res) => res.sendFile(path.join(frontendDir, 'index.html')));

// Unknown /api routes get a clear error.
app.use('/api', (_req, res) => res.status(404).json({ error: 'That API address does not exist.' }));

app.listen(config.port, () => {
  console.log(`\nORT WATT is running.`);
  console.log(`Open your browser at:  http://localhost:${config.port}\n`);
});

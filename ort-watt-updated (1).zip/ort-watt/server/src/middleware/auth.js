// =========================================================
//  auth.js (middleware) — the "security guard" for routes.
//
//  Runs BEFORE a protected route. It checks the login token
//  the browser sends and, when needed, the user's role.
// =========================================================

import jwt from 'jsonwebtoken';
import { config } from '../config.js';

// The visitor must be logged in.
export function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: 'You must be logged in to do that.' });
  }
  try {
    req.user = jwt.verify(token, config.jwtSecret); // { id, role, email }
    next();
  } catch {
    return res.status(401).json({ error: 'Your session has expired. Please log in again.' });
  }
}

// The visitor must be logged in AND have one of the given roles.
export function requireRole(...allowedRoles) {
  return (req, res, next) => {
    requireAuth(req, res, () => {
      if (!allowedRoles.includes(req.user.role)) {
        return res.status(403).json({ error: 'You do not have permission for that.' });
      }
      next();
    });
  };
}

// Read a token if present, but don't require it (for guest forms).
export function optionalAuth(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return null;
  try {
    return jwt.verify(header.slice(7), config.jwtSecret);
  } catch {
    return null;
  }
}

// =========================================================
//  db.js — the database. A single file (data/ort.db).
//
//  SQLite needs no separate program to install. This file
//  opens the database and, on first run, creates every table,
//  seeds the equipment categories, and creates your admin
//  account. Nothing to run by hand.
//
//  better-sqlite3 is synchronous, which keeps the code simple:
//    db.prepare(sql).run(...)   → insert / update / delete
//    db.prepare(sql).get(...)   → one row
//    db.prepare(sql).all(...)   → many rows
// =========================================================

import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { config } from './config.js';

// Make sure the data folder exists.
fs.mkdirSync(path.dirname(config.dbFile), { recursive: true });

export const db = new Database(config.dbFile);
db.pragma('journal_mode = WAL');   // safer, faster writes
db.pragma('foreign_keys = ON');    // enforce table links

// Generate a random, hard-to-guess id (used as every table's key).
export const newId = () => crypto.randomUUID();

// ---- Create tables (only if they don't already exist) ----
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id            TEXT PRIMARY KEY,
    first_name    TEXT NOT NULL,
    last_name     TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    mobile        TEXT,
    whatsapp      TEXT,
    company       TEXT,
    country       TEXT,
    role          TEXT NOT NULL DEFAULT 'customer'
                  CHECK (role IN ('customer','staff','admin')),
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS categories (
    id         TEXT PRIMARY KEY,
    slug       TEXT NOT NULL UNIQUE,
    name_en    TEXT NOT NULL,
    name_fr    TEXT NOT NULL,
    name_ar    TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS products (
    id                TEXT PRIMARY KEY,
    category_id       TEXT REFERENCES categories(id) ON DELETE SET NULL,
    brand             TEXT NOT NULL,
    model             TEXT NOT NULL,
    slug              TEXT NOT NULL UNIQUE,
    name_en           TEXT NOT NULL,
    name_fr           TEXT NOT NULL,
    name_ar           TEXT NOT NULL,
    power_capacity    TEXT,
    reference_price   REAL NOT NULL DEFAULT 0,
    fee_percent       REAL NOT NULL DEFAULT 10,
    price_verified_on TEXT,
    quality_score     REAL,
    ort_label         TEXT DEFAULT 'ORT SELECTED'
                      CHECK (ort_label IN ('ORT SELECTED','ORT VERIFIED','ORT APPROVED','ORT PREMIUM')),
    why_selected_en   TEXT,
    why_selected_fr   TEXT,
    why_selected_ar   TEXT,
    purchase_mode     TEXT NOT NULL DEFAULT 'quote'
                      CHECK (purchase_mode IN ('buy','quote')),
    availability      TEXT NOT NULL DEFAULT 'in_stock'
                      CHECK (availability IN ('in_stock','on_request','out_of_stock')),
    image_path        TEXT,
    datasheet_path    TEXT,
    is_published      INTEGER NOT NULL DEFAULT 0,
    created_at        TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS product_scores (
    product_id      TEXT PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE,
    reliability     REAL,
    value_for_money REAL,
    performance     REAL,
    warranty        REAL,
    spare_parts     REAL
  );

  CREATE TABLE IF NOT EXISTS requests (
    id         TEXT PRIMARY KEY,
    user_id    TEXT REFERENCES users(id) ON DELETE SET NULL,
    kind       TEXT NOT NULL CHECK (kind IN ('quote','study','ask_engineer','installation')),
    product_id TEXT REFERENCES products(id) ON DELETE SET NULL,
    full_name  TEXT,
    email      TEXT,
    mobile     TEXT,
    country    TEXT,
    city       TEXT,
    message    TEXT,
    status     TEXT NOT NULL DEFAULT 'new'
               CHECK (status IN ('new','in_review','quoted','answered','closed')),
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS request_files (
    id            TEXT PRIMARY KEY,
    request_id    TEXT NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
    file_path     TEXT NOT NULL,
    original_name TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS suppliers (
    id             TEXT PRIMARY KEY,
    name           TEXT NOT NULL,
    country        TEXT,
    rating         TEXT CHECK (rating IN ('A','B','C','D') OR rating IS NULL),
    certifications TEXT,
    notes          TEXT,
    created_at     TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_products_category  ON products(category_id);
  CREATE INDEX IF NOT EXISTS idx_products_published ON products(is_published);
  CREATE INDEX IF NOT EXISTS idx_requests_user      ON requests(user_id);
  CREATE INDEX IF NOT EXISTS idx_requests_status    ON requests(status);
`);

// ---- Seed the equipment categories (no products, on purpose) ----
const categorySeed = [
  ['complete-systems', 'Complete Solar Systems', 'Systèmes solaires complets', 'أنظمة شمسية متكاملة', 1],
  ['panels',           'Solar Panels',           'Panneaux solaires',          'الألواح الشمسية',       2],
  ['inverters',        'Inverters',              'Onduleurs',                  'العواكس',               3],
  ['batteries',        'Lithium Batteries',      'Batteries lithium',          'بطاريات الليثيوم',      4],
  ['controllers',      'Charge Controllers',     'Régulateurs de charge',      'منظمات الشحن',          5],
];
const insertCategory = db.prepare(`
  INSERT INTO categories (id, slug, name_en, name_fr, name_ar, sort_order)
  VALUES (?, ?, ?, ?, ?, ?)
  ON CONFLICT(slug) DO NOTHING
`);
for (const c of categorySeed) insertCategory.run(newId(), ...c);

// ---- Create the first admin account (only if missing) ----
const adminExists = db.prepare('SELECT id FROM users WHERE email = ?').get(config.adminEmail);
if (!adminExists) {
  const hash = bcrypt.hashSync(config.adminPassword, 10);
  db.prepare(`
    INSERT INTO users (id, first_name, last_name, email, password_hash, role)
    VALUES (?, 'ORT', 'Admin', ?, ?, 'admin')
  `).run(newId(), config.adminEmail, hash);
  console.log(`→ Created admin account: ${config.adminEmail}`);
}

console.log('→ Database ready:', config.dbFile);

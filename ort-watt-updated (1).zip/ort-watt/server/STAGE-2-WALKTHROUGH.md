# Stage 2 — Walkthrough

You have never run a backend before. This document assumes that and
explains everything. Work through it in order and stop at any point
where something does not match what is described.

---

## Part 0 — What you are about to do, in plain words

Your website has two halves.

**The half you have seen** is the pages: HTML, styling, images. Those
are just files. A browser opens them and draws them. Nothing is
remembered, nothing is sent anywhere.

**The half you have not seen** is the server. It is a program that runs
continuously, waits for the website to ask it something, and answers.
When a customer fills in your Ask an Engineer form, the page hands the
answers to the server, and the server writes them down.

Three words you will keep meeting:

| Word | What it actually means here |
|---|---|
| **Server** | A program that waits for requests and answers them. Yours is in the `server` folder. It has never been run. |
| **Database** | A file that remembers things after the program stops. Yours is a single file: `server/data/ort.db`. Copy that file and you have copied every customer request you have ever received. |
| **API** | The doorway between the two halves. Your forms knock on `/api/requests`. |

**Nothing here touches the internet.** Everything in this document runs
on your own computer and is visible only to you. Putting the site
online is a later, separate step.

**You cannot break anything permanently.** The database creates itself.
If it ends up in a mess, delete `server/data/ort.db` and start over.

---

## Part 1 — Install Node

Node is the thing that can run the server program. You install it once.

1. Go to **https://nodejs.org**
2. Download the button marked **LTS** (it means "the stable one")
3. Install it like any other application, accepting the defaults
4. Restart your computer if the installer asks

### Check it worked

Open a terminal:

- **Mac** — press `Cmd + Space`, type `Terminal`, press Enter
- **Windows** — press the Start key, type `PowerShell`, press Enter

Type this and press Enter:

```
node --version
```

You should see something like `v20.11.0` or higher. If you see
"command not found", Node did not install correctly, or you need to
close and reopen the terminal.

---

## Part 2 — Point the terminal at the project

The terminal is always "standing in" some folder. You need it standing
in the `server` folder.

Type `cd` followed by a space — **do not press Enter yet** — then drag
the `server` folder from your file browser onto the terminal window.
It will fill in the path for you. Now press Enter.

Check you are in the right place:

```
node check.js
```

This is a tool I wrote for you. It inspects everything the server needs
and explains any problem in plain language, with the exact fix. Run it
whenever something seems wrong.

Right now it will tell you one thing is missing. That is expected.

---

## Part 3 — Download the building blocks

The server is built partly from free, public components (a web server,
a database driver, a password scrambler). They are not included in the
project — you download them once.

```
npm install
```

This needs internet, takes a minute or two, and prints a lot of text.
Warnings in yellow are normal and can be ignored. Errors in red are not.

It creates a `node_modules` folder. **Never edit anything inside it**,
and never email or upload it — if you move the project to another
computer, you just run `npm install` again there.

Now run the check again:

```
node check.js
```

It should say **"Everything is ready."**

---

## Part 4 — Start the server

```
npm start
```

You should see something close to:

```
ORT WATT is running.
Open your browser at:  http://localhost:4000
```

Several things just happened silently, and they matter:

- The database file `server/data/ort.db` was created
- The tables inside it were created (users, products, requests, ...)
- An administrator account was created so you can log in

**The terminal is now busy.** That is correct — the server is running,
and it will keep printing there. Do not close that window.

To stop the server: click the terminal, press **Ctrl + C** (Ctrl, not
Cmd, even on a Mac).

---

## Part 5 — See it working

Open a browser and go to:

```
http://localhost:4000
```

`localhost` means "this computer". `4000` is the door number. Nobody
else on earth can reach this address.

You should get the language screen, then your site — exactly as before.
But now it is being *served*, not just opened as a file, and the forms
have somewhere to go.

### The moment that matters

1. Go to **Ask an Engineer**
2. Fill in the form with anything — use your own email
3. Submit it

If you see the confirmation message, **your website just wrote to a
database for the first time.** That is the whole of backend
development, in miniature: a form on a page, a program that receives
it, a file that remembers it.

---

## Part 6 — Prove it was really saved

A confirmation message is a claim. Let us verify it.

Stop the server (Ctrl + C), then:

```
node peek.js
```

This prints what is actually stored in the database. Your test request
should be listed. If it is, the loop is closed and the whole thing
works.

---

## Part 7 — Log in as administrator

The server created an admin account on first run:

- **Email:** `admin@ortwatt.com`
- **Password:** `ChangeMe123`

Go to `http://localhost:4000/login.html` and sign in.

> **Change that password before this site is ever public.** It is
> written in a file that ships with the project, so it is not a secret.
> We will do this properly when we set up the staff area in Stage 3.

---

## Part 8 — Getting told when someone submits

You have found the real gap yourself: a request sits in the database
until somebody thinks to look. That is not good enough for a promise of
"within one business day".

So the server now sends **two emails** every time a form is submitted:

1. **To your team** — who wrote in, what they said, what they attached,
   and the address to reply to
2. **To the customer** — an acknowledgement with a reference number,
   the one-business-day promise, and WhatsApp as the faster route

### First, see them without setting anything up

```
node testmail.js
```

With no email account configured, the server runs in **outbox mode**: it
writes each email to a file in `server/data/outbox` instead of sending
it. `testmail.js` prints them so you can read exactly what your
customers and your team would receive.

Nothing is broken in this mode, and nothing is lost. Requests still save
normally. It just means nobody is told yet.

### Then, to send them for real

You need an email account the server can send through. Two sensible
options:

| Option | Good for | Watch out for |
|---|---|---|
| **Your existing business email** (Gmail, Outlook, your host) | Starting out, no cost | Gmail needs an "app password", not your normal one. Daily sending limits. |
| **A sending service** (Brevo, Resend, Mailgun) | Once you have real volume | Free tiers are generous; requires verifying your domain |

Start with the first. Copy the example settings file:

```
cp .env.example .env
```

Open `.env` in any text editor and fill in:

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your.address@gmail.com
SMTP_PASS=your-app-password
NOTIFY_EMAIL=where-you-want-alerts@example.com
MAIL_FROM=ORT WATT <your.address@gmail.com>
```

> **On Gmail:** your normal password will not work. Turn on 2-step
> verification, then create an **App Password** under Google Account →
> Security. Use that 16-character code as `SMTP_PASS`.

> **`.env` holds passwords.** Never email it, never upload it, never
> put it in a public place. It is already excluded from the project zip.

Now test again:

```
node testmail.js
```

It should say **"Email is live"** and two messages should arrive. If
nothing appears within a few minutes, check the spam folder before
assuming it failed.

Then restart the server (`Ctrl + C`, then `npm start`) and submit a real
form on the site to see the whole loop work.

### The rule this is built on

**Email can never break a submission.** The server saves the request and
answers the customer *first*, then tries to send email afterwards. If
your mail account is wrong, misconfigured, or offline, the customer
still gets their confirmation and the request is still safely in the
database. You would simply not be told about it — which `node peek.js`
will always reveal.

---

## Part 8b — Sending as ORT WATT (domain verification)

To make emails arrive from **ORT WATT &lt;hello@ortwatt.com&gt;**
rather than a Gmail address, you have to prove you own the domain.

### Why this exists

Anyone can *type* `ortwatt.com` into a From field. Because of that,
mail providers ignore the claim unless the domain itself vouches for the
sender. Verification is the domain publicly saying "this service may
send on my behalf."

Skip it and your mail lands in spam. This is not a Resend rule — it is
how email works everywhere.

---

### Step 1 — You need a domain

If ORT WATT does not own one yet, buy it before anything else. It
costs roughly **$10–15 a year** at Namecheap, Cloudflare or Porkbun, and
you need it for the website itself anyway.

### Step 2 — Create the Resend account

1. Go to **resend.com** and sign up (free tier: 3,000 emails a month)
2. Open **Domains** → **Add Domain**
3. Type `ortwatt.com` and continue

Resend now shows you a table of records. **Leave that page open.**

### Step 3 — Understand what you are copying

Those records are public notes attached to your domain. Each has three
parts:

| Column | Means | Example |
|---|---|---|
| **Type** | The kind of note | `TXT` or `MX` |
| **Name** / Host | Where it is filed | `resend._domainkey` |
| **Value** | The note itself | a long string of characters |

You will be adding roughly three: a **DKIM** record (the cryptographic
signature that proves an email really came from you), an **SPF** record
(which servers are permitted to send as you), and sometimes an **MX**
record on a `send.` subdomain to catch bounces.

### Step 4 — Add them at your registrar

Log in wherever you bought the domain and find **DNS**, or **DNS
Records**, or **Manage DNS**. Add each record from the Resend table:
choose the Type, paste the Name, paste the Value, leave TTL alone.

> **The mistake almost everyone makes.** Many registrars automatically
> add your domain to whatever you type in the Name box. If the box shows
> `.ortwatt.com` beside it, enter only:
>
> ```
> resend._domainkey
> ```
>
> not the full `resend._domainkey.ortwatt.com` — otherwise you end
> up with `resend._domainkey.ortwatt.com.ortwatt.com`, which
> matches nothing. If verification keeps failing, check this first.

> **Do not touch your existing MX records.** If anyone already receives
> email at `@ortwatt.com`, those MX records on the bare domain are
> what deliver it. The Resend one goes on the `send.` subdomain, so they
> do not collide — but only if you *add* rather than *replace*.

### Step 5 — Check the records went live

```
node checkdns.js ortwatt.com
```

This reads the public internet exactly as a mail provider would, and
tells you which records it can see. It also checks that your existing
mailboxes are still intact.

DNS changes usually appear within minutes, occasionally hours. If a
record is missing, wait and run it again before changing anything.

### Step 6 — Verify, then connect

When `checkdns.js` looks right, return to Resend and press **Verify**.

Then create an API key (**API Keys** → **Create**), and put it in your
`.env`:

```
RESEND_API_KEY=re_xxxxxxxxxxxxxxxx
MAIL_FROM=ORT WATT <hello@ortwatt.com>
NOTIFY_EMAIL=team@ortwatt.com
```

Restart the server and run:

```
node testmail.js
```

### Before the domain is verified

Resend will only let you email **your own address**. That is enough to
prove team alerts work, but customer acknowledgements will not send
until verification completes. Everything still saves; nothing is lost.

---

## Part 9 — Two honest limits before you go further

**1. No customer can reach this site yet.**
`localhost` means "this computer". The site is running, but only for
you. Nobody else on earth can open it. Putting it on a real address is
a separate step called hosting, and it belongs after Stage 3 — there is
no point publishing a catalogue with six placeholder products in it.

So "the client can be doing all of these" is not yet true. Right now the
email path matters because you want it proven *before* real customers
arrive, not because any have.

**2. The reply promise is now in four places.**
The site says one business day on the Ask an Engineer page, in the form
confirmation, and in the acknowledgement email — and WhatsApp is
advertised as faster. Those are promises to real people. Before this is
public, decide who watches WhatsApp and the notification inbox, and
during which hours. A promise the site keeps making and the team cannot
keep is worse than no promise.

---

## If something goes wrong

Run `node check.js` first — it explains most problems itself.

| What you see | What it means | What to do |
|---|---|---|
| `command not found: node` | Node is not installed, or the terminal needs restarting | Redo Part 1 |
| `command not found: npm` | Same — npm arrives with Node | Redo Part 1 |
| `EADDRINUSE` | Something already uses door 4000 | `PORT=4100 npm start`, then use `http://localhost:4100` |
| `Cannot find module` | The building blocks are missing | `npm install` |
| `NODE_MODULE_VERSION` mismatch | Database component was built for a different Node | `npm rebuild better-sqlite3` |
| Page loads but forms fail | The server is not running | Start it with `npm start` |
| Form works but no email arrives | Email is in outbox mode | `node testmail.js` explains why |
| Resend will not verify the domain | Usually a doubled Name field | `node checkdns.js yourdomain.com` |

Copy the **exact** error text when reporting a problem. The specific
words are what identify the cause.

---

## What comes next, and why

Once the above works, the honest state of Stage 2 is this: the pages
exist and the forms save. What is still missing is that **nobody is
told when a request arrives** — it sits in the database until somebody
looks.

Notification is now built (Part 8). Once you have it sending for real,
Stage 2 is genuinely finished: a customer can ask, and both sides are
told.

**Stage 3 is next**, and it is the one that changes your day to day: a
staff area where you add and edit real products yourself, with no
developer involved. That is also when my placeholder products go away.

Before I build it, we need to agree how a product is structured —
particularly the specification table, because that is painful to change
once you have typed in fifty products. I will draft it for you to look
at first.

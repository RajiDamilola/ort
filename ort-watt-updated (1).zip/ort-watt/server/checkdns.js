#!/usr/bin/env node
/* =========================================================
   checkdns.js — "are my domain records live yet?"
   ---------------------------------------------------------
   After you add the DNS records at your registrar, run this to
   see whether they have taken effect. It reads the public
   internet, exactly as a mail provider would.

   Run it with:
       node checkdns.js ortwatt.com

   READ ONLY. It only looks things up; it changes nothing.
   ========================================================= */

import dns from 'dns';

/* Some name servers answer slowly or not at all. Without a time limit
   this tool can appear to freeze, which is alarming when you are just
   trying to find out whether a record exists. Every lookup gets 6
   seconds, then gives up and reports honestly. */
const RAW = dns.promises;
const LIMIT_MS = 6000;
const withLimit = fn => (...args) => Promise.race([
  fn(...args),
  new Promise((_, rej) => setTimeout(() => rej(new Error('TIMEOUT')), LIMIT_MS)),
]);
const R = {
  resolveTxt: withLimit(RAW.resolveTxt.bind(RAW)),
  resolveMx:  withLimit(RAW.resolveMx.bind(RAW)),
  resolveNs:  withLimit(RAW.resolveNs.bind(RAW)),
};

const B='\x1b[1m', D='\x1b[2m', G='\x1b[32m', Y='\x1b[33m', RED='\x1b[31m', O='\x1b[0m';

const domain = (process.argv[2] || '').trim().replace(/^https?:\/\//,'').replace(/\/.*$/,'');

if (!domain) {
  console.log(`\n${Y}Tell me which domain to check.${O}`);
  console.log(`Example:  ${B}node checkdns.js ortwatt.com${O}\n`);
  process.exit(0);
}

console.log(`\n${B}Checking DNS for ${domain}${O}`);
console.log(`${D}Reading the public internet, the same way an email provider would.${O}\n`);

let done = 0, missing = 0;
const ok   = m => { done++;    console.log(`  ${G}FOUND${O}    ${m}`); };
const no   = (m, hint) => { missing++; console.log(`  ${RED}MISSING${O}  ${m}`);
                            if (hint) console.log(`           ${D}${hint}${O}`); };
const note = m => console.log(`  ${D}${m}${O}`);

/* ---------- 0. Does the domain exist at all? ---------- */
try {
  await R.resolveNs(domain);
  console.log(`${B}The domain itself${O}`);
  ok(`${domain} exists and has name servers.`);
} catch {
  console.log(`${B}The domain itself${O}`);
  no(`${domain} does not resolve.`,
     `Either it is not registered yet, or it was bought minutes ago and is still settling. Wait an hour and retry.`);
  console.log(`\n${D}Nothing else can be checked until this works.${O}\n`);
  process.exit(0);
}

/* ---------- 1. DKIM — the signature that proves it is you ---------- */
console.log(`\n${B}1. DKIM  ${D}(proves the email really came from you)${O}`);
const dkimNames = [`resend._domainkey.${domain}`, `send._domainkey.${domain}`];
let dkimFound = false;
for (const name of dkimNames) {
  try {
    const recs = await R.resolveTxt(name);
    const flat = recs.map(r => r.join('')).join('');
    if (flat.length) {
      ok(`${name}`);
      note(`value starts: ${flat.slice(0, 48)}...`);
      dkimFound = true;
      break;
    }
  } catch { /* try the next name */ }
}
if (!dkimFound) {
  no(`No DKIM record found at resend._domainkey.${domain}`,
     `Add the TXT record Resend showed you. Careful with the Name field — see the note at the end.`);
}

/* ---------- 2. SPF — says who is allowed to send ---------- */
console.log(`\n${B}2. SPF  ${D}(says which servers may send as you)${O}`);
let spfFound = false, spfTimeout = false;
for (const host of [`send.${domain}`, domain]) {
  try {
    const recs = await R.resolveTxt(host);
    const spf = recs.map(r => r.join('')).find(v => v.toLowerCase().startsWith('v=spf1'));
    if (spf) {
      ok(`${host}  ->  ${spf.slice(0, 90)}${spf.length > 90 ? '...' : ''}`);
      if (/amazonses|resend/i.test(spf)) note(`Includes Resend's sender. Good.`);
      else note(`This SPF does not mention Resend. If Resend asked for one, add it.`);
      spfFound = true;
    }
  } catch (e) {
    if (e.message === 'TIMEOUT') spfTimeout = true;
  }
}
if (!spfFound) {
  if (spfTimeout) note(`The lookup timed out. Your name server was slow — try again in a moment.`);
  else no(`No SPF record found on send.${domain} or ${domain}`,
          `Add the TXT record Resend listed. If Resend did not ask for one, you can ignore this.`);
}

/* ---------- 3. MX on the sending subdomain ---------- */
console.log(`\n${B}3. MX on send.${domain}  ${D}(handles bounces)${O}`);
try {
  const mx = await R.resolveMx(`send.${domain}`);
  if (mx.length) { ok(`send.${domain}`); mx.forEach(m => note(`${m.priority}  ${m.exchange}`)); }
  else no(`No MX record on send.${domain}`);
} catch {
  no(`No MX record on send.${domain}`,
     `Only needed if Resend listed one. Some setups do not use it.`);
}

/* ---------- 4. Your real inbox — must not be broken ---------- */
console.log(`\n${B}4. Your existing mailboxes  ${D}(this must not be damaged)${O}`);
try {
  const mx = await R.resolveMx(domain);
  if (mx.length) {
    ok(`${domain} still has MX records, so incoming mail still works.`);
    mx.forEach(m => note(`${m.priority}  ${m.exchange}`));
  }
} catch {
  note(`No MX on ${domain} itself.`);
  note(`If nobody receives email at @${domain}, that is expected and fine.`);
  note(`${Y}If they DO, something has removed it — restore it before going further.${O}`);
}

/* ---------- 5. DMARC — optional but improves delivery ---------- */
console.log(`\n${B}5. DMARC  ${D}(optional; helps you stay out of spam)${O}`);
try {
  const recs = await R.resolveTxt(`_dmarc.${domain}`);
  const v = recs.map(r => r.join('')).find(x => x.toLowerCase().startsWith('v=dmarc1'));
  if (v) ok(`_dmarc.${domain}  ->  ${v}`);
  else note(`Not set. Optional.`);
} catch {
  note(`Not set. Optional, but worth adding later:`);
  note(`TXT  _dmarc  ->  v=DMARC1; p=none; rua=mailto:you@${domain}`);
}

/* ---------- Verdict ---------- */
console.log(`\n${B}${'-'.repeat(56)}${O}`);
if (missing === 0) {
  console.log(`${G}${B}Records look right.${O}`);
  console.log(`Go back to Resend and press ${B}Verify${O}. It should turn green.\n`);
} else {
  console.log(`${Y}${B}${missing} record${missing>1?'s are':' is'} not visible yet.${O}\n`);
  console.log(`Two ordinary reasons:`);
  console.log(`  1. ${B}Not enough time.${O} Usually minutes, occasionally hours.`);
  console.log(`     Wait, then run this again.\n`);
  console.log(`  2. ${B}The Name field got doubled.${O} This is the most common mistake.`);
  console.log(`     Many registrars add your domain automatically, so entering`);
  console.log(`     ${D}resend._domainkey.${domain}${O} becomes`);
  console.log(`     ${RED}resend._domainkey.${domain}.${domain}${O}`);
  console.log(`     If your registrar shows the domain next to the box, enter`);
  console.log(`     only ${B}resend._domainkey${O}\n`);
}

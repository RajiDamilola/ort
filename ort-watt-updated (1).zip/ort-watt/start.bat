@echo off
REM Double-click this file (Windows) to launch ORT WATT.
cd /d "%~dp0server"
if not exist node_modules (
  echo First run: installing (this happens once)...
  call npm install
)
call npm start
pause

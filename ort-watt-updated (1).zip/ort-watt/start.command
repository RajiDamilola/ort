#!/bin/bash
# Double-click this file (Mac) to launch ORT WATT.
cd "$(dirname "$0")/server"
if [ ! -d node_modules ]; then
  echo "First run: installing (this happens once)..."
  npm install
fi
npm start

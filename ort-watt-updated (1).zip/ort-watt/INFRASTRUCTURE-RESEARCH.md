# ORT WATT — Infrastructure Research & Capacity Report

Prepared in response to the technical review request.

---

## Before anything else: what is measured, what is modelled

Your questions ask for **testing**. That distinction matters, so let me
be exact about which is which.

| Finding | Basis |
|---|---|
| Page weight (384 KB desktop / 259 KB mobile) | **Measured** on the built site |
| Image savings from WebP (39%) / AVIF (61%) | **Measured** by converting the real hero image |
| Connection limits, compute sizes, credit rates | **Published vendor documentation**, cited below |
| Concurrency, bandwidth, monthly cost | **Modelled** from the above, assumptions stated |
| Response times under 500/900/2,000 users | **Not yet measured — cannot be** |

**Nothing can be load-tested until the site is deployed.** There is no
URL to send traffic to. Anyone presenting you with concurrency test
results today has produced them from imagination.

What I have done instead is build the test itself. `ops/loadtest.js`
runs exactly the four levels you asked for, against a staging
deployment, and reports which component is the constraint. It should be
run before launch, and the modelled figures below replaced with measured
ones.

---

## 1. Concurrent users, and where "900" comes from

### The number is real, and I can tell you its source

Your 900 figure is almost certainly **Neon's `max_connections` for a
2 CU database**, which is exactly **901**.

Neon publishes this table:

| Compute size | RAM | max_connections |
|---|---|---|
| 0.25 CU | 1 GB | 104 |
| 0.5 CU | 2 GB | 225 |
| 1 CU | 4 GB | 450 |
| **2 CU** | 8 GB | **901** |
| 4 CU | 16 GB | 1,802 |
| 8 CU | 32 GB | 3,604 |
| 9 CU and above | — | capped at 4,000 |

So "900" is not a Netlify limit, not a visitor limit, and not a guess.
It is the number of simultaneous *Postgres connections* a mid-sized
database allows.

### Why it does not limit you to 900 users

Two reasons, and both matter.

**First — it only applies to direct connections.** Neon's documentation
states the pooled endpoint *"supports up to 10,000 concurrent client
connections by multiplexing them over a smaller pool of real Postgres
connections."* The fix is a single character change: add `-pooler` to
the database hostname.

```
# Direct — limited to max_connections (901 at 2 CU)
postgresql://user:pass@ep-xxxxx.eu-central-1.aws.neon.tech/db

# Pooled — accepts up to 10,000 clients
postgresql://user:pass@ep-xxxxx-pooler.eu-central-1.aws.neon.tech/db
```

Neon's own guidance is explicit: *"For Lambdas, Vercel Functions,
Cloudflare Workers, or any connection-per-request framework, use the
pooled string."* Serverless functions are exactly that. **Using the
pooled string is not optional for this architecture — it is required,
and forgetting it is the single most likely cause of a production
outage.**

**Second — a connection is held for milliseconds, not for a session.**
This is the part most capacity discussions get wrong.

A visitor reading a product page for three minutes is not holding a
database connection for three minutes. They hold one for roughly 15 ms
per query, perhaps a dozen times per session.

Working it through:

```
2,000 concurrent visitors
× 12 queries per 180-second session
× 15 ms per query
= 2.0 database queries genuinely in flight at any instant
```

**Two.** Against a pool of 94 on the smallest database, or 810 on a 2 CU
one. The database is not remotely the constraint.

### The modelled picture

| Visitors/day | Peak concurrent | With 3× campaign spike | Concurrent DB queries |
|---|---|---|---|
| 1,000 | 6 | 18 | ~0.0 |
| 5,000 | 30 | 90 | ~0.1 |
| 10,000 | 60 | 180 | ~0.2 |
| 20,000 | 120 | 360 | ~0.4 |
| 50,000 | 300 | 900 | ~0.9 |

*Peak concurrency uses Little's Law: busiest hour ≈ 12% of daily
traffic, 180-second sessions.*

### So what IS the bottleneck?

In order of which you would hit first:

**1. Bandwidth credits — the real constraint.** Netlify bills 20 credits
per GB. At 20,000 visitors/day you would use roughly 190 GB/month, or
about 5,500 credits against Pro's 3,000. **This is what actually costs
you money, and it is dominated by images** (Section 7).

**2. Function concurrency on CPU-bound work.** Reads are cheap. Password
hashing is deliberately expensive — bcrypt is designed to be slow.
Login is the request most likely to queue under sudden load. The load
test measures it separately for this reason.

**3. Cold starts.** Neon suspends the database after 5 minutes idle;
the first query then pays *"a cold-start penalty (around hundreds of
ms)"*. On a quiet site the first visitor of the morning waits. Mitigated
by disabling scale-to-zero on the Launch plan, at the cost of paying for
an always-on database.

**4. Connection exhaustion — only if pooling is misconfigured.** With
the direct string you would fail at a few hundred concurrent function
invocations. With the pooled string this is not reachable at your scale.

**Honest answer to "why 900": it is not your limit.** It is a Postgres
setting on one database size, bypassed by connection pooling. Your
practical ceiling is bandwidth cost, which arrives far sooner.

---

## 2. Database — exact specification

| Item | Answer |
|---|---|
| **Provider** | Neon (serverless Postgres), available as Netlify DB |
| **Plan** | Start **Free** (100 CU-hours, 0.5 GB). Move to **Launch** at real traffic |
| **Location** | **AWS eu-central-1, Frankfurt** — nearest well-connected region to Dubai (~108 ms round trip vs ~257 ms for US East) |
| **Compute** | Autoscaling **0.25 – 2 CU**. 1 CU = 1 vCPU + 4 GB RAM |
| **Max capacity** | Autoscaling to 16 CU; fixed sizes to 56 CU |
| **Connections** | 104 direct at 0.25 CU → **10,000 via pooler** |
| **Pool size** | 90% of max_connections per user/database |
| **Auto-scaling** | Yes, sub-second, between your min and max |
| **Scale to zero** | After 5 min idle. Free: always on. Launch: can disable |
| **Backups** | Point-in-time restore. Free: 6 hours. Launch: 7 days. Scale: 30 days |
| **Cost** | $0.106/CU-hour, storage $0.35/GB-month, egress 100 GB free then $0.10/GB |

**Recommended production setting:** autoscale **0.25 – 2 CU**, pooled
connection string, scale-to-zero **disabled** once you have steady
traffic (to remove the cold start), 7-day point-in-time restore.

**To increase capacity:** raise the autoscaling maximum. It is a slider
in the console, applies without downtime, and needs no code change.

> **Set the autoscaling maximum deliberately.** Neon's documentation
> notes that autoscaling limits *"act as a built-in cost ceiling: your
> database will never scale beyond the limit you set, even during
> traffic spikes."* This is your protection against a runaway bill.

---

## 3. Traffic and performance

Measured page weight, from the actual built site:

| Component | Size (compressed) |
|---|---|
| HTML | 7.5 KB |
| CSS | 23.1 KB |
| JavaScript | 69.0 KB |
| Hero image (desktop) | 284.6 KB |
| Hero image (mobile) | 159.6 KB |
| **First visit, desktop** | **384 KB** |
| **First visit, mobile** | **259 KB** |
| **Repeat visit** | **7.5 KB** |

Modelled at 3.2 pages and ~332 KB per session:

| Visitors/day | Bandwidth/month | Credits needed | Plan |
|---|---|---|---|
| 5,000 | 48 GB | ~1,500 | Pro (3,000) — comfortable |
| 10,000 | 95 GB | ~2,830 | Pro — near the limit |
| 20,000 | 190 GB | ~5,490 | Pro + extra credits |
| 50,000 | 475 GB | ~13,470 | Pro + substantial extra |

**Pages, search, product images, accounts, cart and checkout are all
included** in that session model.

### What happens during an advertising campaign

The site **does not fall over** — that is the central advantage of this
architecture. Static pages come from the CDN with effectively unlimited
concurrency, functions scale out per request, and the database (as shown
above) is nowhere near loaded.

**The exposure is financial.** A campaign that trebles traffic trebles
bandwidth, and bandwidth is billed by usage.

> **Two protections, both configured before launch:** a Netlify spending
> cap, and a Neon autoscaling maximum. Together they convert an
> unbounded bill into a known one.

---

## 4. Cost at each traffic level

| | 5,000/day | 10,000/day | 20,000/day | 50,000/day |
|---|---|---|---|---|
| Netlify plan | Pro $20 | Pro $20 | Pro + credits | Pro + credits |
| Bandwidth | 48 GB | 95 GB | 190 GB | 475 GB |
| Neon compute | ~$11 | ~$11 | ~$11 | ~$11 |
| Neon storage | ~$2 | ~$2 | ~$2 | ~$2 |
| Neon egress | free | free | free | ~$1 |
| Email (Resend) | free | free | ~$20 | ~$20 |
| **Estimated total** | **~$33/mo** | **~$33/mo** | **~$55–75/mo** | **~$120–180/mo** |

*Figures above 10,000/day include additional credit purchases, whose
per-unit rate should be confirmed with Netlify directly before
committing — that is the one number I would not rely on from
documentation alone.*

**With image optimisation applied** (Section 7), bandwidth falls about
22%, which pushes the point at which you outgrow Pro from roughly
10,000/day to roughly 13,000/day.

---

## 5. Security

### Provided by the platform

| Protection | Status |
|---|---|
| SSL/HTTPS | Included, auto-renewed, HTTP redirects |
| DDoS mitigation | At the CDN layer, included |
| Platform patching | Vendor's responsibility |
| No exposed server | No SSH, no admin port, no OS to harden |
| No CMS or plugins | Removes the most common small-site attack route |

A configurable **WAF** is an Enterprise feature. Given you will not
store card details, platform-level protection is proportionate.

### Application security — already built

- Passwords hashed with bcrypt
- Every write requires a valid signed token
- Roles enforced server-side per action, not hidden in the interface
- Customers cannot read other customers' data
- Uploads restricted by type and size

### Application security — OUTSTANDING, must be done before launch

1. **Default admin password ships in the code** (`ChangeMe123`).
   Fix: forced change on first login; server refuses to start in
   production while the default is present.
2. **Token signing secret is still the example value.** Anyone knowing
   it could forge an admin session without a password.
   Fix: generated random secret in environment configuration.
3. **No login rate limiting.** Nothing prevents automated guessing.
   Fix: throttling and lockout.

**These are the three things standing between the current build and a
site that is safe to publish.**

### E-commerce specific

- **Never store card numbers.** Use Stripe, Checkout.com or Telr, where
  the card is entered on their page. This removes the entire PCI
  compliance burden.
- **Validate prices server-side at checkout.** Never trust a price sent
  from the browser — this is the classic e-commerce exploit.
- **Rate limit checkout and enquiry endpoints** against card testing and
  spam.

---

## 6. Backups and disaster recovery

| Question | Answer |
|---|---|
| How often | Continuous — point-in-time, not nightly snapshots |
| Retention | Free 6 hours · Launch 7 days · Scale 30 days |
| Stored separately | Within the provider's infrastructure |
| Restore speed | Site rollback: seconds. Database restore: typically under an hour |
| Cost | $0.20/GB-month for retained history |

### The gap, stated plainly

Vendor backups protect against **vendor failure**. They do **not**
protect against your account being closed, compromised, or billed into
suspension. In those scenarios the backups are behind the same locked
door as the data.

**I will add an independent export** — a scheduled dump to storage you
control, outside both Netlify and Neon. This is cheap and it is the only
backup that survives losing the account.

> A backup nobody has restored is a hope, not a backup. **Test a restore
> twice a year.**

---

## 7. Images and product catalogue — the highest-value change

This is where the money is, and I tested it on your actual hero image.

| Format | Size | Saving |
|---|---|---|
| JPEG q80 (current) | 285 KB | — |
| **WebP q78** | **173 KB** | **39%** |
| WebP q70 | 149 KB | 48% |
| AVIF q60 | 112 KB | 61% |

### Recommendation

**Use Netlify Image CDN.** It converts to WebP or AVIF automatically
based on what each browser supports, resizes on request, and caches the
result. No separate service, no extra bill, no upload workflow to build.

**Do not put product images in the code repository.** Store them in
object storage and serve through the image CDN. Product photography
changes constantly; code deployments should not be involved.

**Cloudinary** is excellent and more capable, but it is a separate
subscription solving a problem you do not yet have. Revisit it if you
later need heavy transformation, video, or automated background removal.

### Practical rules for the catalogue

- Serve product images at the size actually displayed, never full size
  scaled down in the browser
- `loading="lazy"` on everything below the fold
- Cap uploads at ~2,500 px on the long edge; nothing needs more
- Keep the source files — you can always re-derive, never re-invent

**Impact: roughly 22% off total bandwidth**, which is 22% off your
largest variable cost.

---

## 8. Scalability and the upgrade path

| Traffic | Action | Rebuild required? |
|---|---|---|
| 0 – 5,000/day | Free or Pro, 0.25–1 CU | — |
| 5,000 – 15,000/day | Pro, autoscale to 2 CU, images optimised | No |
| 15,000 – 40,000/day | Extra credits, 2–4 CU, add caching | No |
| 40,000 – 100,000/day | Review: read replicas, CDN tuning | No, but architectural attention |
| 100,000+/day | Dedicated infrastructure review | Likely yes |

**When to upgrade:** watch three signals — credits above ~80% of plan
allowance, database p95 latency rising under load, or cold starts
becoming noticeable. Each has a specific remedy, and none requires a
rewrite.

**Answering your question directly:** yes, this scales 10× without
rebuilding. Every step to roughly 50,000 visitors/day is a setting
change, not a migration. That is the single strongest argument for this
architecture over a fixed server.

---

## Is there a better architecture?

I considered three seriously.

**A traditional VPS with Postgres** (~$10–25/month, flat). Cheaper and
more predictable at high traffic, and no credit anxiety. But *you* patch
the OS, renew certificates, monitor disk, and restart it at 2am. **You
do not currently have anyone to do that** — which is the deciding
factor, not the price.

**Shopify or similar** (~$29–79/month). Removes nearly all of this.
But your entire proposition — the ORT quality score, the published
selection reasoning, transparent fee separation, the engineering
enquiry flow — is custom. You would be fighting the platform to
reproduce what you have already built.

**Netlify + Neon.** Recommended, with two conditions: use the pooled
connection string, and set both spending caps.

**My honest conclusion: the architecture is right.** The risk in this
project is not technical. It is that **nobody is yet responsible for the
site once customers depend on it**, and that the three security items
above are still open.

---

## Recommended production configuration

| Layer | Choice | Cost |
|---|---|---|
| Hosting | Netlify Pro | $20/mo |
| Database | Neon (Netlify DB), Frankfurt, autoscale 0.25–2 CU, **pooled** | ~$13/mo |
| CDN | Netlify, included | $0 |
| Images | Netlify Image CDN + object storage | $0 |
| Email | Resend, verified domain | $0 to 3,000/mo |
| SSL | Included | $0 |
| Backups | 7-day PITR **+ independent export** | ~$2/mo |
| Monitoring | Netlify Analytics + Neon monitoring + uptime check | $0–9/mo |
| **Total** | | **~$35–45/month** at 5,000–10,000 visitors/day |

---

## What must happen before launch

1. Migrate SQLite → Postgres *(cheapest now, before real data exists)*
2. **Use the pooled connection string** — non-negotiable for serverless
3. **Close the three security items in Section 5**
4. Convert images to WebP/AVIF via the image CDN
5. Set the Netlify spending cap **and** the Neon autoscaling maximum
6. Deploy to staging and **run `ops/loadtest.js` at 500 / 900 / 2,000**
7. Replace the modelled figures in this report with measured ones
8. Add the independent database export
9. **Decide who is responsible when something breaks**

Item 9 is not technical, and it is the one most often left undone.

---

## Sources

- Neon connection pooling and `max_connections` by compute size
- Neon plans, autoscaling limits, scale-to-zero, point-in-time restore
- Neon pricing: CU-hour, storage and egress rates
- Netlify credit-based pricing and plan allowances

*Vendor pricing and limits change. Confirm current figures before
committing, particularly the per-credit overage rate.*

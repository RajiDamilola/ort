# ORT WATT — Infrastructure Specification

Prepared for review before going live.

---

## Before the answers: three things you should know

**1. I am not a hosting provider, and I am not an agency.**
Several of your questions — who performs maintenance, what the
guaranteed response time is, who is on call — are about a *commercial
relationship*, not about technology. I cannot answer those, and any
answer I gave would be worthless. They are marked clearly below, and
they matter: an excellent infrastructure with nobody responsible for it
fails like any other.

**2. Your site is not a CMS.**
Questions about "CMS, plugin and security updates" assume WordPress or
similar. Yours has no CMS, no plugins, and no theme. That is genuinely
good news: most small-business site compromises come through outdated
plugins, and you have none. It also means the maintenance burden is
smaller than the question implies.

**3. The site is not production-ready today, and I want that on record.**
Three security items are outstanding (Section 4). They are known,
listed, and must be completed before launch. I would rather you see them
here than discover them after.

---

## 1. Hosting

### Recommendation

**Netlify** — Free plan to start, moving to Pro when traffic justifies it.

**Why:** your site is mostly static pages served from a CDN, with a
small amount of server code for forms, accounts and the catalogue. That
is exactly the shape Netlify is built for. It removes an entire class of
work you would otherwise own — operating system patching, web server
configuration, TLS certificate renewal, process supervision.

### Type

**Serverless / platform-as-a-service.** Not shared hosting, not a VPS,
not a dedicated server.

| Layer | What runs it |
|---|---|
| Pages, images, CSS, JS | Netlify's global CDN |
| Forms, login, catalogue API | Netlify Functions (server code that wakes per request) |
| Database | Netlify DB — serverless PostgreSQL, provided by Neon |
| Uploaded files (bills, roof photos) | Netlify Blobs — object storage that survives deployments |

### Server location

Static content is served from **the CDN edge nearest each visitor**, so
a customer in Dubai is served from the Gulf region rather than from a
single origin.

Choose the **database region closest to your customers** — for Dubai and
the wider Gulf, an EU region (Frankfurt) is the sensible default and is
noticeably faster than a US region for mobile users.

### Alternative, for completeness

A **VPS** (Hetzner, DigitalOcean, ~$5–10/month) gives more control and
flat, predictable billing. It also makes you responsible for OS updates,
firewall rules, certificate renewal, backups and restarts. That is a real
job. I do not recommend it as a first step, but it is the natural
destination if the business grows substantially or billing predictability
becomes more important than convenience.

---

## 2. Capacity and performance

These figures are calculated from **your actual built site**, not from
generic assumptions.

### Measured page weight

| Item | Size (compressed) |
|---|---|
| HTML | 7.5 KB |
| CSS | 23.1 KB |
| JavaScript | 69.0 KB |
| Hero image, desktop | 284.6 KB |
| Hero image, mobile | 159.6 KB |
| **First visit, desktop** | **384 KB** |
| **First visit, mobile** | **259 KB** |
| **Repeat visit** (cached) | **7.5 KB** |

Fonts (~180 KB) load from Google's CDN and are not billed to your host.

### Realistic traffic capacity

Assumes 75% mobile, 2.5 pages per session, 8 deployments per month.

| Plan | Cost | Sessions / month | Visitors / day |
|---|---|---|---|
| Free | $0 | ~29,000 | **~980** |
| Personal | $9/mo | ~144,000 | **~4,800** |
| Pro | $20/mo | ~471,000 | **~15,700** |

**Apply a 40% safety margin.** Those figures assume credits go to
bandwidth alone; compute and web requests also draw on the same pool.
Plan on roughly **600/day free, 2,900/day Personal, 9,400/day Pro.**

For context: a regional solar supplier typically sees 50–500 visitors a
day in its first year. **The free plan is likely to be sufficient for
some time**, and the paid tiers are there when campaigns land.

### Simultaneous visitors

Not a meaningful limit on this architecture. Static pages are served
from CDN edge nodes with effectively unlimited concurrency, and
functions scale out automatically per request.

The real constraint is **database connections**, not visitors. Serverless
Postgres uses connection pooling; hundreds of concurrent users are
comfortable. You would be into thousands-concurrent before this needed
architectural attention.

### Storage, RAM, CPU

These are not allocated the way they are on a VPS. There is no fixed RAM
or CPU figure because there is no fixed server — capacity is provisioned
per request. Storage is metered rather than capped, and your data is
tiny by any measure: product records and text requests are kilobytes;
only customer uploads accumulate meaningfully.

### Sudden traffic spikes

**This architecture handles them better than a fixed server would.** A
VPS with fixed RAM falls over when it is exhausted; a CDN plus
serverless functions simply serves more.

The exposure is **financial, not technical**. Credit-based billing means
a viral moment produces a bill rather than an outage.

> **Set a spending cap on day one.** Netlify supports this. Without one,
> usage-based billing can surprise you. This is the single most important
> configuration step, and it is not on by default.

---

## 3. Scalability

**Upgrading is a plan change, not a migration.** Free → Personal → Pro is
a billing setting. No downtime, no code change, no data move.

**5× or 10× traffic:** absorbed by the CDN and function auto-scaling. You
would move up a plan for the credits, not rebuild anything.

**Where this architecture would eventually strain:** sustained heavy
database write volume — thousands of orders per day — or large media
libraries. Neither is near-term. At that point the answer is a larger
database tier, still not a rewrite.

**The honest ceiling:** this design is comfortable to roughly
15,000 visitors/day and hundreds of orders/day. Beyond that, expect to
revisit the database tier and caching strategy — a tuning exercise, not
a rebuild.

---

## 4. Security

### Included by the platform

| Protection | Status |
|---|---|
| SSL / HTTPS | Included free, auto-renewed. HTTP redirects to HTTPS. |
| DDoS mitigation | Included at the CDN layer |
| Platform patching | Netlify's responsibility, not yours |
| No exposed server | There is no SSH port, no admin panel on a server to attack |
| No CMS or plugins | Removes the most common compromise route for small sites |

A dedicated **WAF** with custom rules is an Enterprise feature. For your
threat profile — a catalogue and enquiry forms, no card processing —
platform-level protection is proportionate.

### Application security: built

- Passwords stored hashed with bcrypt, never in readable form
- Every write to products or requests requires a valid signed token
- Roles enforced **on the server** for each action, not hidden in the UI
- Customers cannot read other customers' requests
- Uploads restricted by type and size

### Application security: OUTSTANDING — must be done before launch

These are real, and I am flagging them rather than letting them ship
quietly:

1. **The default admin password (`ChangeMe123`) ships in the code.**
   Harmless locally; a published key the moment the site is public.
   Fix: forced change on first login, and the server refusing to start
   in production while the default is in place.

2. **The token signing secret is a default value.** Anyone who knows it
   could forge an admin session without a password. Fix: a generated
   random secret, stored as an environment variable.

3. **No rate limiting on login.** Nothing prevents automated password
   guessing. Fix: attempt throttling and lockout.

I will complete these as part of the Stage 3 work. **The site must not
go live until they are done.**

### Customer data

You store names, emails, phone numbers, enquiry text and uploaded
documents. You do **not** store card details — and I would keep it that
way. When you take payments, use a provider (Stripe, Checkout.com,
Telr) whose page handles the card so the numbers never touch your
server. That removes the entire PCI compliance burden.

---

## 5. Backups

**Database:** Netlify DB includes automated backups with point-in-time
recovery, so you can restore to a moment before a mistake rather than to
the previous night.

**Site code:** every deployment is retained. Rolling back to a previous
version is one click, and takes seconds.

**Uploaded files:** stored in Blobs, replicated by the platform.

**What I will add regardless:** a scheduled export of the database to
storage you control. Platform backups protect against platform failure;
they do not protect against your own account being lost or closed. A copy
you hold is a different kind of insurance, and it is cheap.

**Restore time:** minutes for a code rollback; typically under an hour
for a database point-in-time restore.

---

## 6. Availability

**Expected uptime: 99.9%+** in practice — roughly 45 minutes of
unavailability a month at worst, usually far less.

Note honestly: a formal, contractual **SLA of 99.99% is an Enterprise
plan feature**. On Free/Personal/Pro you get the same infrastructure but
no contractual guarantee or compensation.

**If a node fails,** the CDN routes around it automatically. There is no
single server to go down — that is the main reliability advantage over a
VPS, where one machine failing means the site is offline until someone
intervenes.

**Failover** is inherent to the architecture rather than something
configured.

---

## 7. Database and e-commerce

**PostgreSQL** (via Netlify DB / Neon). Industry standard, relational,
handles concurrent writes correctly, well understood.

> Note: the current build uses SQLite, chosen so you could run the site
> with zero setup. Moving to PostgreSQL is part of the hosting work, and
> **now is the cheapest possible moment** — you have six placeholder
> products and no real customer data. The same move after a year of
> trading is a genuinely stressful migration.

**Limits:** none that you will encounter. PostgreSQL handles millions of
rows without complaint. Tens of thousands of products, customers and
orders are unremarkable. Your practical limit is commercial — how many
products your engineers can properly evaluate — not technical.

---

## 8. Maintenance — I cannot answer this for you

This section is about people, and it needs deciding.

**What genuinely needs maintaining:**

| Item | Frequency | Who |
|---|---|---|
| Operating system, web server, TLS | Continuous | Netlify — not you |
| CMS / plugins | — | Does not apply, you have none |
| Application dependencies | Every few months | **Needs an owner** |
| Content and products | Ongoing | Your team, via the Stage 3 admin |
| Watching for failed emails / errors | Weekly | **Needs an owner** |
| Restore drill (test a backup actually restores) | Twice yearly | **Needs an owner** |

**Response time in an incident: I cannot commit to one.** I have no
on-call obligation and cannot promise availability. If ORT WATT
needs a guaranteed response, that requires a retained developer or
agency with a written agreement. **That gap is worth closing before you
depend on the site commercially.**

The last row matters more than it looks. **A backup nobody has ever
restored is a hope, not a backup.** Test it twice a year.

---

## 9. Email

Two different things, often confused:

**Mailboxes** — where `hello@ortwatt.com` receives mail. Use **Google
Workspace** (~$6/user/month) or **Microsoft 365**. Do not use free
registrar-bundled email for a business address.

**Transactional email** — order confirmations, password resets, request
acknowledgements. Use **Resend** (3,000/month free). Already built into
your server and tested.

### Staying out of spam

Deliverability depends on three DNS records, all part of the
verification already described:

- **SPF** — which servers may send as you
- **DKIM** — a cryptographic signature proving the mail is genuine
- **DMARC** — what receivers should do if a message fails the first two

With all three correct, and sending from a verified domain, delivery to
the inbox is reliable. **Do not send transactional mail from a Gmail
address** — that is what lands in spam.

---

## 10. Costs

### Year one, realistic

| Item | Cost |
|---|---|
| Domain (Cloudflare or Porkbun) | **$10–15 / year** |
| Netlify Free | **$0** |
| Netlify Personal, if traffic grows | $9 / month |
| Netlify Pro, at scale | $20 / month |
| Resend, up to 3,000 emails/month | **$0** |
| SSL certificate | **Included** |
| CDN | **Included** |
| Database | Included in plan credits |
| Google Workspace mailbox | ~$6 / user / month (optional) |

**Starting total: about $15 for the first year**, plus mailboxes if you
want them. Rising to roughly **$110–250/year** once traffic warrants a
paid tier.

### Renewal

Domain renews annually at a similar rate — **check the renewal price, not
the first-year offer.** Hosting is month to month, cancellable.

### What is charged separately

Nothing hidden on the platform side. SSL, CDN and backups are included.
The variable is **credits**: bandwidth, compute and deploys draw on the
monthly allowance, and exceeding it costs more. Hence the spending cap.

### Setup cost

No third-party setup fees. The remaining work is the PostgreSQL
migration, the Stage 3 admin area, the three security items, and
deployment.

---

## Summary: the realistic ceiling

| Metric | Comfortable limit before change |
|---|---|
| Visitors per day | ~9,400 on Pro (with safety margin) |
| Simultaneous users | Hundreds; not the binding constraint |
| Products | Tens of thousands |
| Orders per day | Hundreds |
| First architectural review | Sustained 15,000+ visitors/day |

You are unlikely to approach these in the first few years. When you do,
the response is a larger plan and a bigger database tier — **not a
rebuild.** That is the main argument for this architecture over a fixed
VPS: it grows with a setting rather than a migration.

---

## What must happen before launch

1. Migrate SQLite → PostgreSQL *(cheapest now, before real data exists)*
2. Move uploads to Blobs
3. **Close the three security items in Section 4**
4. Build Stage 3 so real products replace the placeholders
5. Set the spending cap
6. Verify the domain for email
7. Add the independent database export
8. **Decide who owns maintenance and incident response**

Item 8 is not technical, and it is the one most often left undone.

---

*Pricing verified against Netlify's published 2026 rates at the time of
writing. Usage-based pricing changes; confirm current figures before
committing.*
